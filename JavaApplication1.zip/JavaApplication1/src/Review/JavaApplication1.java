package Review;

import java.util.Scanner;

public class JavaApplication1 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter the number of rows for the pyramid:");
        int rows = scanner.nextInt();

        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < i; j++) {
                System.out.print(" ");
            }
            for (int k = i; k < rows; k++) {
                System.out.print("* ");
            }
            System.out.println();
      
        
        
//        for(int i = 1; i <= rows; i++){
//            for(int j = rows; j > rows - i; j--  ){
//                System.out.print(" ");
//            }
//            for(int k = rows; k >= i; k--){
//                 System.out.print("* ");
//            }
//             System.out.println();
//                
//        }
           /*for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i-1; j++){
                System.out.print(" ");
            }
            for (int k =0; k <=rows-i; k++  ) {
                System.out.print("* ");
            }
            System.out.println();*/
        }
    }
    

}
