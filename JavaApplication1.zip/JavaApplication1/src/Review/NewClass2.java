package Review;

import java.util.Scanner;

public class NewClass2 {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your frist number:");
        int num1 = scanner.nextInt();

        System.out.print("Enter your second number:");
        int num2 = scanner.nextInt();

        System.out.print("Enter your operator +;-;*;/;%:");
        char oparetor = scanner.next().charAt(0);

        int result = 0;
        switch (oparetor) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    System.out.println("volue is not Zero");
                    return;
                }
                break;
            case '%':
                if (num2 != 0) {
                    result = num1 % num2;
                } else {
                    System.out.println("volue is not Zero");
                    return;
                }
                break;
                
            default:
                System.out.println("In valid oparetor. plase enter one fo +,-,*,/,%");
                return;
        }
        System.out.println("The result is " + result);
    }

}
