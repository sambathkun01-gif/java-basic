package Review;

import java.util.Scanner;

public class NewClass02 {

    public static void main(String[] arge) {

        Scanner scanner = new Scanner(System.in);

        System.out.print("input your number:");
        int cat = scanner.nextInt();

        System.out.print("input your number:");
        int dog = scanner.nextInt();

            
       }
          

        }

    

