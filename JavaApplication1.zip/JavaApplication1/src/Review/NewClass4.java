package Review;
import java.util.HashSet;
public class NewClass4 {
    public static void main(String [] args){
        HashSet<String> cars = new HashSet<String>();
        cars.add("ford");
        cars.add("Volvo");
        cars.add("Mazda");
       // cars.remove("vovlo");
       for (String  i  : cars){
        System.out.println(cars);
       }
    }
    
}
