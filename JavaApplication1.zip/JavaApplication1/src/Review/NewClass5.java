package Review;
public class NewClass5 {
   public static void myMethod(){
       System.out.println("I love you");
    }
   public static void main(String [] args){
       myMethod ();
       myMethod();
   }
    
}
