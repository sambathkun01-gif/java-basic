package Review;
import java.util.Scanner;
import java.text.DecimalFormat;
public class Exercies {
    public static void main (String args []){
         Scanner input = new Scanner(System.in);
        DecimalFormat df = new DecimalFormat("#,##0.00");

        System.out.println("Enter information");
        // ចំនួនប្រាក់កម្ចី (ដុល្លា)
        System.out.print("Enter Loan Amount:$");
        double bank = input.nextDouble();
        
        // អាត្រាការប្រាក់ប្រចាំឆ្នាំ
        System.out.print("Enter Monthly Interest Rate​​:%");
        double annualRate = input.nextDouble();
        
        // រយៈពេលកម្ចី (ឆ្នាំ)
        System.out.print("Enter Term Year:");
        int years = input.nextInt();
        // គណនាតម្លៃចាំបាច់
        double monthlyRate = annualRate / 100 / 12;
        int totalMonths = years * 12;
        
        // គណនាការទូទាត់ប្រចាំខែ
        double monthlyPayment;
        if(annualRate == 0) {
            monthlyPayment = bank / totalMonths;
        } else {
            double power = Math.pow(1 + monthlyRate, totalMonths);
            monthlyPayment = (bank * monthlyRate * power) / (power - 1);
        }
        
        // គណនាទឹកប្រាក់សរុប
        double totalPaid = monthlyPayment * totalMonths;
        double totalInterest = totalPaid - bank;
         // បង្ហាញលទ្ធផល
        System.out.println("Results");
        System.out.println("MonthlyPayment: " + (monthlyPayment) + "$");
        System.out.println("Total Payment: " + (bank) + "$");
        System.out.println("TotalInterest: " + (totalInterest) + "$");
        System.out.println("TotalPaid: "+df.format(totalPaid) + "$");
        
        input.close();

         
        
        
        
    }
    
}
