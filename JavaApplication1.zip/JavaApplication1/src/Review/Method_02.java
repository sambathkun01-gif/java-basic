
package Review;

public class Method_02 {
    public static void main(String [] args){
          myMethod("lid",34);  
        
    }
        static void myMethod(String name,int age){
            System.out.println(name+" is "+age);
        }
        
        
    }
    

