package Review;

import java.util.Scanner;

public class NewClass_Assignment {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your number :");
        int son = scanner.nextInt();
        int output = son;
        System.out.println(output += 3);
        System.out.println(output -= 5);
        System.out.println(output *= 2);
        System.out.println(output /= 2);
        System.out.println(output %= 3);

    }
}
