
package Review;
import java.util.Scanner;
public class ex2 {
    public static void main (String [] args){
       Scanner scanner = new Scanner(System.in);

        System.out.print("Enter Loan Amount: $");
        double loanAmount = scanner.nextDouble();

        System.out.print("Enter Monthly Interest Rate: %");
        double monthlyInterestRate = scanner.nextDouble();

        System.out.print("Enter Term Year: ");
        int termYear = scanner.nextInt();

        int totalMonth = termYear * 12;
        double interssRate = monthlyInterestRate / 12 / 100;

        double monthlyPayment = loanAmount * (interssRate * Math.pow(1 + interssRate, totalMonth)) /
                (Math.pow(1 + interssRate, totalMonth) - 1);

        double totalPayment = monthlyPayment * totalMonth;
        double Interest = totalPayment - loanAmount;

        System.out.println("Monthly Payment : $" + monthlyPayment);
        System.out.println("Total Payment : $" + totalPayment);
        System.out.println("Interest Rate : $" + Interest); 
    }
    
}
