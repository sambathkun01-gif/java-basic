
package Review;

public class Method_ReturnVolue_04 {
  
   static int myMethod(int x, int y) {
    return x + y;
  }

  public static void main(String[] args) {
    int z = myMethod(5, 3);
    System.out.println(z);
  }
}    


