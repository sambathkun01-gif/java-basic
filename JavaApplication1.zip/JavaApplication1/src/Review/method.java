
package Review;

public class method {
    public static void main(String [] args){
        number();
    }
    public static  int number(){
       int X = 5;
       int y =5;
       int z = X+y;
       System.out.println(z);
       return 0;
    }
}
