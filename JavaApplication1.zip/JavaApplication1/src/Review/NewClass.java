package Review;
import java.util.Scanner;

public class NewClass {
    public static void main(String [] args){
        Scanner scanner = new Scanner (System.in);
        System.out.println("Enter old value:");
        int oldValue = scanner.nextInt();
        System.out.println("Enter new value :");
        int newValue = scanner.nextInt();
        int usage = oldValue + newValue;
        System.out.println("Usage"+usage);
        if (usage <=50){
            int cost= usage*500;
            System.out.println("cose"+cost+"riel");
        }else {
            int cost = usage*750;
            System.out.println("cost"+cost+"riel");
        }
    }
    
}
