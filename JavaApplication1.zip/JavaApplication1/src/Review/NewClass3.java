
package Review;
import java.util.HashMap;

public class NewClass3 {
    public static void main (String [] args){
        HashMap<String,String> bag = new HashMap <String,String>();
        bag.put("bag1","pen");
        bag.put("bag2", "pencail");
        bag.put("bag3", "rullor");
        System.out.println(bag);
        System.out.println(bag.get("bag1"));
        bag.remove("bag3");
        System.out.println(bag);
        for(String i : bag.keySet()){
            System.out.println(i+bag.get(i));
        }
        
        
    }
    
}
