package Review;

import java.util.Scanner;

public class NewClass01 {

    public static void main(String[] arge) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("input your want Unit :");
        int dog = scanner.nextInt();
        
        System.out.print("input your want Lesson :");
        int pig = scanner.nextInt();
        
//        System.out.print ("input your operator:");
//        int cat = scanner.nextInt();
       
        for (int i=1; i<dog+1; i++ ){
            System.out.println("Unit"+i);
            for(int j=1; j<pig+1; j++){
                System.out.println("Lesson"+j);
                
            }
            System.out.println("===================");
        }
    }
}