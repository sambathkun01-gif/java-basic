package Review;

public class TimeNumber {

    public static void main(String[] args) {
        int[] number = {1};
        for (int i = 1; i < 10 + 1; i++) {
            System.out.println(number[0]);
        }
        
        
         }  

        }
    
