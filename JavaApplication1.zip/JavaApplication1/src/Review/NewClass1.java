
package Review;
public class NewClass1 {
    public static void main(String [] args){
        int oldNumber = 10;
        int newNumber =50 ;
        int total = oldNumber + newNumber;
       System.out.println(total);
        if (total<=50){
             int cost = total*500;
            System.out.println(cost);
        }else if (total>50){
             int cost = total*750;
            System.out.println(cost);
        }
         
    
            
        
    }
     
    
}
