package BassicJava;
import java.io.File;
import java.io.IOException;
public class java6_rename {
    public static void main (String [] args)throws IOException{
        File file = new File("test.txt");
        File file2 = new File ("newName.txt");
        if (file2.exists()){
            throw new java.io.IOException("file exists");
        }
        boolean success = file.renameTo(file2);
        if (success){
            System.out.println("File renamed");
        }
    }
    
}
