package BassicJava;
import java.util.HashSet;

public class Java11_hashset {
    public static void main (String [] args){
        HashSet <String> cars = new HashSet<String>();
        cars.add("Volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");
       // cars.remove("Volvo");  
        for(String i: cars){
         System.out.println(i);  
        }
    }   
}
