package BassicJava;
public class Class02_output{
    public static void main (String [] args){
        //print string in java 
        System.out.println("Hello Java");
        System.out.println("I am learning Java");
        System.out.println("It is awesome");
        System.out.println(3+3);
        
        System.out.println("Hello World!");
        System.out.println("I will print on the som line");
    }
    
}
