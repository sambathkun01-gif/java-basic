
package BassicJava;
class Pet {
    public void petSound (){
       System.out.println("The animal makes a sound ");
    }
}
class Cat extends Pet {
    public void petSound(){
        System.out.println("The pig say : wee wee");
    }
}
class Dog extends Pet {
    public void petSound(){
        System.out.println("The dog say: bow wow");
    }
}

public class Oop12_polymorphism {
    public static void main(String [] args){
        Pet myAnimal = new Pet();
        Pet myPig = new Cat ();
        Pet myDog = new Dog ();
        myAnimal.petSound ();
        myPig.petSound();
        myDog.petSound();
    }
    
}

