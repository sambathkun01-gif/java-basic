package BassicJava;

public class Oop02_attribute {
    int x = 5;
    public static void main(String [] args){
        Oop02_attribute myobj1 = new Oop02_attribute();
        Oop02_attribute myobj2 = new Oop02_attribute();
        myobj2.x = 25;
        System.out.println(myobj1.x);
        System.out.println(myobj2.x);
    }
    
}
