   package BassicJava;
public class Class05_print{
    public static void main(String [] args){
        String name = "sambath";
        System.out.println("Hello " +name);
        
        String firstName = "Kun";
        String LastName = "Samabth";
        String fullName = firstName +" "+ LastName;
        System.out.println(fullName);
        
        int x = 5;
        int y = 6;
        System.out.println(x + y);
        
        int xl = 5;
        int yl = 6;
        int zl = 50;
        System.out.println(xl + yl + zl);
        
        int x2 = 5, y2 = 6, z2 =50;
        System.out.println(x2 + y2 + z2);
        
        int x3, y3, z3;
        x3 = y3 = z3 = 50;
        System.out.println(x3 + y3 + z3);
                
        
    }
}