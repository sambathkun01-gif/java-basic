
package BassicJava;

import java.util.HashMap;
public class Java08_hashmap {
    public  static void main(String [] args){
        HashMap<String, String> capitalcities = new HashMap<String ,String >();
        capitalcities.put("English", "London");
        capitalcities.put("Germany", "Berlis");
        capitalcities.put("NorWay", "Oslo");
        capitalcities.put("USA", "wasindon D.C");
        for(String i: capitalcities.values()){
            System.out.println(i);
        }
    }
    
}
