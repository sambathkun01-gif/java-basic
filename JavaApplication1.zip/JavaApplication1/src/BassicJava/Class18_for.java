package Bassicjava;
public class Class18_for{
    public static void main(String [] args){
        int i;
        for(i = 0 ; i <= 10; ++i){
            System.out.println("Hello java"+i);    
        }
        int j;
        for(j = 10; j>=1; --j){
            System.out.println("World"+j);
        }    
        int k;
        for(k = 0; k<=10;k +=2){
           System.out.println(k);
        }
        
    }
    
}

