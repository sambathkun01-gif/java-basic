package BassicJava;
public class Class03_comment{
    public static void main (String [] ages){
        //this code is Used to print string
        System.out.println("Hello world");
        /*
        this is line 1
        this is line 2
        */
        
    }
}
