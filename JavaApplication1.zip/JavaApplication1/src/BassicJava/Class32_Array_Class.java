package BassicJava;

import java.util.Arrays;

public class Class32_Array_Class {

    public static void main(String[] args) {
        double[] numbers = {6.0, 4.4, 1.9, 2.9, 3.4, 3.5};
        Arrays.sort(numbers);
        System.out.println(Arrays.toString(numbers));
        // array must be short
        int myIndex = Arrays.binarySearch(numbers, 3.4);
        System.out.println(myIndex);
    }
}
