package BassicJava;

public class Class28_loop_in_array {

    public static void main(String[] args) {
        String[] mycars = {"volvo", "BMW", "Ford", "Mazda"};
         
        // output indate array
        for (int i = 0; i < mycars.length; i++) {
            System.out.println("My car is " + mycars[i]);
        }
        //output teat array
        for (String car : mycars) {
            System.out.println(car);
        }

    }

}
