package BassicJava;
import java.util.ArrayList;
public class Java01_array_list {
    public static void main(String [] args){
        ArrayList<String>cars = new ArrayList<String>();
        cars.add("Volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");
        System.out.print("cars");
        cars.remove("Mazda");
        System.out.println(cars);
    }
    
}
