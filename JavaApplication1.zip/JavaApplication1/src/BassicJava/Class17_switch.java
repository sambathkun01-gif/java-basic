package Bassicjava;
public class Class17_switch{
    public static void main (String [] args){
        int day = 2;
        switch (day){
            case 1:
                System.out.println("Sunday");
                break;
            case 2:
                System.out.println("Monday");
                break;
            case 3:
                System.out.println("Tuesday");
                break;
            
            case 4:
                System.out.println("Wednesday");
                break;
            case 5:
                System.out.println("Thursday");
                break;
            case 6:
                System.out.println("Friday");
                break;
            default:
                System.out.println("Saturday");
                break;
        }
        char weekday = 'd';
        switch (weekday){
            case 'a':
                System.out.println("Suday");
                break;
            case 'b':
                System.out.println("Monday");
                break;
            case 'd':
                System.out.println("Tuesday");
                break;
            case 'e':
                System.out.println("Wednesday");
                break;
            case 'f':
                System.out.println("Thursday");
                break;
            case 'g':
                System.out.println("Friday");
                break;
            default:
                System.out.println("Saturday");
                break;
               
        }
    }
}