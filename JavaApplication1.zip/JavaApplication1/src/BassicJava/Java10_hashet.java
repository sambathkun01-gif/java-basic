package BassicJava;
import java.util.HashSet;
public class Java10_hashet {
    public static void main(String [] args){
        HashSet<String> cars = new HashSet<String>();
        cars.add ("volvo");
        cars.add ("BMW");
        cars.add ("Ford");
        cars.add ("Mazda");
        System.out.println(cars);
        System.out.println(cars.contains ("Mazda"));
        cars.remove("volvo");
        System.out.println(cars);
    }
    
}
