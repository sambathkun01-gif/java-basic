package Bassicjava;

public class Class24_break {

    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {
            if (i == 4) {
                break;
            }
            System.out.println("Hello" + i);
        }
    }
}
