
package BassicJava;

public class Oop09_encapuletion {
    public static void main(String [] args){
        Person myobj = new Person ();
    }
    
}
class Person {
    private String name;
    public String getname(){
        return name ;
    }
    public void setName (String newName){
        this.name = newName;
    }
}