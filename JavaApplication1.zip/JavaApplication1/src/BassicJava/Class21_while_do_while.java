package Bassicjava;
public class Class21_while_do_while{
    public static void main (String [] args){
        int i = 0;
        while (i<5){
            System.out.println("java"+i);
            ++i;
        }
        int k = 0;
        do{
        System.out.println("world"+k);
                
    }while (k<5);
    }
}