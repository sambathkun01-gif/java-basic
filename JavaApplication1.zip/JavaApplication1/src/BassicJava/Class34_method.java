package Bassicjava;

public class Class34_method {

    static void myMethod1() {
        System.out.println("I just got executed");
    }

    static void myMethod2(String firstname) {
        System.out.println(firstname + "Dara");
    }

    static void myMethod3(String fname, int age) {
        System.out.println(fname + "is" + age);
    }

    static int myMethod4(int x) {
        return 5 + x;
    }
    static int myMethod5(int x,int y){
        return x+y;
    }
    static void checkAge(int age){
        if (age>18){
            System.out.println("You are not old enough!");
        }else{
            System.out.println ("You are old engough!");
        }
    }
    
    public static void main(String [] args){
        myMethod1();
        myMethod1();
        myMethod1();
        myMethod2("Hong");
        myMethod3("Heng",22);
        int myvar4 = myMethod4(10);
        System.out.println(myvar4);
        int myvar5 = myMethod5(10,20);
          System.out.println(myvar5);
          checkAge(20);
    }

}
