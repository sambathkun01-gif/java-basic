package BassicJava;

public class Class09_char {

    public static void main(String[] args) {
        char myGade = 'a';
        System.out.println(myGade);

        char myVar1 = 65, myVar2 = 66, myVar3 = 67;
        System.out.println(myVar1);
        System.out.println(myVar2);
        System.out.println(myVar3);

    }
}
