package BassicJava;
   public class Oop06_constructor {
    int x;
    public Oop06_constructor(int y){
        x = y;
    }
    public static void main(String [] args){
        Oop06_constructor myobj = new Oop06_constructor(5);
        System.out.println(myobj.x);
    }
}

