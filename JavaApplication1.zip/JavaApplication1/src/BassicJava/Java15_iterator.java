package BassicJava;
import java.util.HashSet;
import java.util.Iterator;
public class Java15_iterator {
    public static void main(String [] arsg){
        HashSet<Integer> set = new HashSet<>();
        set.add (10);
        set.add (20);
        
        set.add (20);
        set.add(40);
        set.add(50);
        
        Iterator<Integer> it = set.iterator ();
        System.out.println("Iteratc HashSet using iterator : ");
        while (it.hasNext ()){
            System.out.println(it.next()+ " ");
        }
        
        
    }
    
}
