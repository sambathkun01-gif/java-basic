package BassicJava;
import java.util.ArrayList;
public class Java02_array_list {
    public static void main(String [] args){
        ArrayList<String> cars = new ArrayList<String>();
        cars.add("volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazad");
        System.out.println(cars);
        System.out.println(cars.get(3));
        cars.set(3,"Toyota");
        System.out.println(cars.get(3));
    }
    
}
