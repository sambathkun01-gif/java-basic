
package BassicJava;

public class Oop11_interface {
    public static void main (String [] args){
        MyPig myPig = new MyPig ();
        myPig.animalSound ();
        myPig.Sleep ();
    }
    
}
interface MyAnimal{
    public void animalSound();
    public void Sleep();
}
 class MyPig implements MyAnimal{
     public void animalSound () {
         System.out.println("The pig say : wee wee");
     }
     public void Sleep(){
         System.out.println("Zzz");
     }
 }  
                 