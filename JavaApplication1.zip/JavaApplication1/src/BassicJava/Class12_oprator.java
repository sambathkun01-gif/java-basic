package BassicJava;
public class Class12_oprator{
    public static void main(String [] args){
        //Assignment operators
        int x = 10;
        System.out.println(x +=3);
        System.out.println(x -=5);
        System.out.println(x *=2);
        System.out.println(x /=2);
        System.out.println(x %=3);
    
    
    }
    
}
