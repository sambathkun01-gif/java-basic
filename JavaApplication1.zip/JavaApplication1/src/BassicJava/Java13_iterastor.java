
package BassicJava;
import java.util.ArrayList;
import java.util.Iterator;
public class Java13_iterastor {
    public static void main(String [] args){
        ArrayList<String> cars = new ArrayList<String>();
        cars.add ("Volvo");
        cars.add ("Ford");
        cars.add("BMW");
        cars.add("Mazda");
        
        Iterator<String> it = cars.iterator();
        
        System.out.println(it.next());
        
        while (it.hasNext()){
            System.out.println(it.next());
        }
    }
    
}
