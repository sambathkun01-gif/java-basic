
package BassicJava;

public class Oop10_abstraction {
    public static void main(String [] args){
        Pig myPig = new Pig ();
        myPig.animalSound();
        myPig.Sleep();
        
    }
    
}
abstract class Animal{
    public abstract void animalSound();
    public void Sleep(){
        System.out.println("Zzzz");
        
    }
}
class Pig extends Animal{
    public void animalSound(){
        System.out.println("The pig says : wee wee");
    }
}