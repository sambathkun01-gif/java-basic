package BassicJava;
import java.util.HashMap;
public class Java07_HashMap {
    public static void main(String [] args){
        HashMap <String,String> capitalcities = new HashMap<String,String>();
        capitalcities.put("English", "London");
        capitalcities.put("Germany", "Berlin");
        capitalcities.put("Cambodia","Phnom Penh");
        capitalcities.put("Norway", "Oslo");
        capitalcities.put("USA","Wasinton.DC");
        capitalcities.remove("Cambodia");
        for (String i:capitalcities.keySet()){
        System.out.println(i);
    }
    }
    
}
