package BassicJava;

public class Oop01_Class {
    int x = 5;
    public static void main(String [] args){
         Oop01_Class myobj1 = new Oop01_Class();
         Oop01_Class myobj2 = new Oop01_Class();
         System.out.println(myobj1.x);
         System.out.println(myobj2.x);
         Second myobj3 = new Second ();
         System.out.println(myobj3.y);                      
    }
}
class Second{
    int y = 6;
}

