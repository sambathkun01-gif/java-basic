  package BassicJava;
public class Class14_oprator{
    public static void main (String [] args){
        //Logical Operator
        int x = 50;
        int y = 70;
        int Z = 90;
        System.out.println((x >= 50) && (y >= 50) && (Z >= 90));//true
        int exam = 50;
        int project = 80;
        System.out.println((exam >=60) || (project >= 90));//false
        
        boolean pass = true;
        System.out.println(!pass);//fase
    }
}