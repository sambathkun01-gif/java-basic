package Bassicjava;
public class Class25_continue{
    public static void main (String [] args){
        for (int i = 0; i < 10; i++){
            if (i<=4){
                continue;
            }
            System.out.println("Hello" +i );
        }
    }
}
