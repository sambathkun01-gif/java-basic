
package BassicJava;

public class Class30_search_array {
    public static void main (String [] args){
        int [] myNums = {2,4,6,8,7,12};
        int target = 7;
        System.out.println(findValue (target,myNums));
    }
        public static int findValue(int target, int []nums){
            for(int i=0; i<nums.length; i++ ){
            if (target == nums[i]){
                return i;
            }
        } 
            return 0;
        }
        
    }
    

