package BassicJava;

public class Oop04_method {
public    static void  myMethod(){
        System.out.println("Hello world");
       
    }
    public static  void main(String [] args){
        myMethod();
    }
}
