package BassicJava;
public class Class10_type_cast{
    public static void main(String [] args){
    /*      int myInt = 9;
        double myDouble = myInt;
        
        System.out.println(myInt);
        System.out.println(myDouble);*/
        
        double myDouble2 = 9.78d;
        int myInt2 = (int) myDouble2;
        
        System.out.println(myDouble2);
        System.out.println(myInt2);
        
        
    }
}