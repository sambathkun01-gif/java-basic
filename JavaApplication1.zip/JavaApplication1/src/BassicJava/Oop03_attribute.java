package BassicJava;
public class Oop03_attribute {
    String fname = "john";
    String lname = "Doe";
    int age = 24;
    
    public static void main(String [] args){
        Oop03_attribute myobj = new Oop03_attribute();
        System.out.println("Name: "+myobj.fname+" "+myobj.lname);
        System.out.println("Age"+myobj.age);
    }
}
