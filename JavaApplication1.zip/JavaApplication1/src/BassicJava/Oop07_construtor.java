
package BassicJava;

public class Oop07_construtor {
    int modelYear;
String modelName;
public Oop07_construtor(int year , String name){
    modelYear = year;
    modelName = name;
}
public static void main(String [] args){
    Oop07_construtor myCar = new Oop07_construtor (1969,"Mustang");
    System.out.println(myCar.modelYear+" "+myCar.modelName);
}

    
}
