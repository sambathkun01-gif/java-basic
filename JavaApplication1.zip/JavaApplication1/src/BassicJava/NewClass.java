
package BassicJava;


public class NewClass {
    public static void main(String [] args){
        Dog dog1 = new Dog();
    }
    
}
