package BassicJava;
import java.io.FileWriter;
import java.io.IOException;
public class java4_update {
    public static void main(String [] args){
        try{
            FileWriter myWriter = new FileWriter("test.txt",true);
            myWriter.write("/n3 File in java might be tricky , but it is fun enough!");
            System.out.println("successfully wrote to the file.");
        }catch (IOException e){
            System.out.println("An erorr occurred");
            e.printStackTrace();
        }
    }
    
}
