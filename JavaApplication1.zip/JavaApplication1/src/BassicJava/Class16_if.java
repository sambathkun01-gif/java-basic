package Bassicjava;
public class Class16_if{
    public static void main (String [] args){
        int math = 50;
        int khmer = 40;
        int  totalScore = 100;
        
        if (math >= 50){
            System.out.println("pass");
        }
        //===============================
        
        if(khmer >= 50){
        
            System.out.println("pass");    
        } 
        else{
            System.out.println("fail");       
        }
        //===============================
        
        if(totalScore >= 90){
            System.out.println("very good");
        } else if(totalScore >= 80){
            System.out.println("Good");
        }else if (totalScore >= 60){
            System.out.println("Norma");
        }else {
            System.out.println("weak");
        }
    }
}