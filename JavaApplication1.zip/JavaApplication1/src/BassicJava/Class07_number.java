package BassicJava;
public class Class07_number{
    public static void main( String [] args){
        byte myNum = 100;
        System.out.println(myNum);
        
        short myNum2 = 5000;
        System.out.println(myNum2);
        
        int myNum3 = 100000;
        System.out.println(myNum3);
        
        long myNum4 = 1500000000l;
        System.out.println(myNum4);
        
        float myNum5 = 5.75f;
        System.out.println(myNum5);
        
        double myNum6 = 19.99d;
        System.out.println(myNum6);
        
        
    }
}
