
package BassicJava;

public class Oop08_inheritance {
    public static void main (String [] args){
        Car myCar = new Car();
        
        myCar.honk();
        System.out.println(myCar.brang + " "+ myCar.modelName);
    }
    
}
class Vehicle {
    protected String brang = "ford";
    public void honk (){
        System.out.println("Tuot,tuot!");
    }
}
class Car extends Vehicle{
    public String modelName = "Mustang";
}