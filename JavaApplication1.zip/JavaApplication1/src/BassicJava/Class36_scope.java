package BassicJava;

public class Class36_scope {
    public static void main(String [] args){
        int x = 100;
        System.out.println(x);
    }
    
}
