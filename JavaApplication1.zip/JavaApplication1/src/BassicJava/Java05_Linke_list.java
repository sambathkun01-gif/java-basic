package BassicJava;
import java.util.LinkedList;
public class Java05_Linke_list {
    public static void main(String [] rags){
        LinkedList <String> cars = new LinkedList<String>();
        cars.add("volvo");
        cars.add("BMW");
        cars.add("Ford");
        cars.add("Mazda");
        System.out.println(cars);
        
    }
}               