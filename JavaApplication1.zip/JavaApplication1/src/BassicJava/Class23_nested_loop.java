package Bassicjava;
public class Class23_nested_loop{
    public static void main( String [] args){
      for (int i =1; i <= 5; i++){
          System.out.println("Lesson" + i);
      for (int j = 1; j<=3; j++){
          System.out.println("Session"+j);
      }
      System.out.println("===========");
    }
 }
    
}