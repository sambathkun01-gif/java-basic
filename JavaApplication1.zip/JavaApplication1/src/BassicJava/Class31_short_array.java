package BassicJava;

import java.util.Arrays;

public class Class31_short_array {

    public static void main(String[] args) {
        int[] myNums = {4, 2, 1, 3, 5, 9, 6, 8, 7};

        System.out.println(Arrays.toString(myNums));
        for (int i = 1; i < myNums.length; i++) {
            for (int j = 1 + 1; j < myNums.length; j++) {
                if (myNums[i] > myNums[j]) {
                    int temp = myNums[i];
                    myNums[i] = myNums[j];
                    myNums[j] = temp;
                }
            }
        }
        System.out.println(Arrays.toString(myNums));

    }

}
