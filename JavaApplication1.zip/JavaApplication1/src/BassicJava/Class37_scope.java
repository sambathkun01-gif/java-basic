package BassicJava;

public class Class37_scope {
    public static void main(String [] arge){
        //code here CANNOT USE X
        {//This is a block
            //This the block
            int x = 100;
            //code here CANNOT USE X
            System.out.println(x);
        }//The block end here
    }//This the block
    
}
