package BassicJava.Exercise;
import java.util.Scanner;
public class Loop2_average {
    public static void main(String [] args){
        Scanner scanner = new Scanner(System.in);
        
        int sum =0;
        int count = 0;
        
        System.out.println("Enter number (enter -1 to stop:)");
        while (true){
            int number = scanner.nextInt();
            if (number == -1){
                break;
            }
            sum += number;
            count++;
        }
        double average= (count !=0)?(double)sum / count:0;
        System.out.println("sum:"+sum);
        System.out.println("Average"+average);
        
    }
    
}
