package BassicJava.Exercise;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Contact_search {
    public static void main(String [] args){
        try{
            String searchID = "3";
            File myobj = new File ("contact.txt");
            Scanner myReader = new Scanner (myobj);
            boolean found = false ;
            while (myReader.hasNextLine()){
                String data = myReader.nextLine();
                String [] lineSplit = data.split (";");
                if (lineSplit [0].equals (searchID)){
                    found = true;
                    System.out.println("ID"+ lineSplit[0]+ "Name"+ lineSplit[1]+"\n");
                    break;
                }
            }
            if (!found){
                System.out.println("Not found");
            }
            myReader.close();
        }catch (FileNotFoundException e){
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
    }
    
}
