package Bassicjava.Exercise;

public class exercise01 {

    public static void main(String[] args) {
        float a = 5f;
        float b = 10f;
        double c = 0;
        char output = '+';
        switch (output) {
            case '+': c = a + b;
                break;
            case '-':c = a - b;
                break;
            case '/':c = a / b;
                break;
            case '*':c = a * b;
                break;
        }
           System.out.println(c);
    }
}
