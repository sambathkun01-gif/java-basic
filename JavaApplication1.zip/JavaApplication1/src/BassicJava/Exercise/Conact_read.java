package BassicJava.Exercise;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class Conact_read {
    public static void main(String [] args){
        try {
            File myobj = new File("contact.txt");
            Scanner myReader = new Scanner (myobj);
            while (myReader.hasNextLine()){
                String data = myReader.nextLine();
                String [] lineSplit = data.split(";");
                System.out.println("ID"+lineSplit[0]+ "Name; "+ lineSplit[1]+"\n");
 
            }
            myReader.close();
        }catch (FileNotFoundException e){
            System.out.println("An error occured");
            e.printStackTrace();
        }
            
    }
    
}
