package Bassicjava.Exercise;
import java.util.Scanner;
public class exercise03_scanner{
    public static void main (String [] args){
        Scanner sambath = new Scanner(System.in);
       
        System.out.print ("your number1 : ");
        double num1 = sambath.nextDouble();
        
        System.out.print ("your number2 : ");
        double num2 = sambath.nextDouble();
        
        System.out.print ("Enter an operator(+,-,*,/,%)  :");
       
        char operator  = sambath.next().charAt(0);
        double total = 0;
            switch (operator){
                case '+': total = num1+num2;
                break;
                case '-': total = num1-num2;
                break;
                case '*': total = num1*num2;
                break;
                case '/': 
                    if (num2 != 0){
                    total = num1 / num2;
                }else {
                        System.out.print ("Error! Division by Zero");
                        return;
                        }
                    break;
                case '%':
                    if (num2 !=0){
                        total = num1 % num2;
                    }else{
                        System.out.println("Error! Division by Zero");
                        return;
                    }
                    break;
                default:
                    System.out.println("Invalid operator. Please enter one of +,-,*,/,%");
                    return;
            }
            System.out.print("The total is :"+total);
        
    }
}