package Bassicjava.Exercise;
import java.util.Scanner;
public class Loop1_maxMultiplier{
    public static void main(String [] args ){
       Scanner scanner = new Scanner(System.in);
       System.out.print ("Enter the number for the multiplication table:");
       int number =scanner.nextInt();
       
       System.out.print ("Enter the maximun multiplier:");
       int maxMultiplier = scanner.nextInt();
       
       //With for loop
      // System.out.println ("Multiplication table using for loop:");
       for (int i= 1 ; i <=maxMultiplier ; i++){
       System.out.println(number+"*"+i+"="+(number*i));
    }
       //with While loop
     /*  System.out.println("\nMultiplication table using while lopp:");
       int i =1;
       while (i <=maxMultiplier){
           System.out.println (number+"*"+i+"="+(number*i));
       i++
       }*/
     // With do-while
       
      /*System.out.println("\nMultiplication table using while lopp:");
      i=1;
      do{
         System.out.println(number+"*"+i+"="+(number*i));
         i++;
      }while (i<=maxMultiplier);*/
    }
    
}
