package Bassicjava.Exercise;

import java.util.Scanner;

public class Loop4_NumbersBetween {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the starting number :");
        int start = scanner.nextInt();

        System.out.print("Enter the ending number :");
        int end = scanner.nextInt();

        System.out.println("\nPrime numbers between " + start + "and" + end + ":");
        for (int num = start; num <= end; num++) {
            if (isPrime(num)) {
                System.out.print(num + ",");

            }
        }
        System.out.println();
    }

    public static boolean isPrime(int number) {
        if (number <= 1) {
            return false;
        }
        for (int i = 2; i <= Math.sqrt(number); i++) {
            if (number % i == 0) {
                return false;
            }
        }
        return true;

    }

}
