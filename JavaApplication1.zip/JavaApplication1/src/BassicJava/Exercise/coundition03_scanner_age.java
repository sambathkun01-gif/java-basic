package Bassicjava.Exercise;

import java.util.Scanner;

public class coundition03_scanner_age {

    public static void main(String[] rags) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your age:");

        int age = scanner.nextInt();   
        System.out.print("Are you a citizen (yes /no) :");
        String citizenship = scanner.next();
        if (age >= 18   && citizenship.equalsIgnoreCase("yes")){
            System.out.println ("You are eligible to vode.");
        }else {
            System.out.println ("You not elibible to vode.");
        }
    }
}
