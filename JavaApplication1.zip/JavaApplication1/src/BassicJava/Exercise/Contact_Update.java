package BassicJava.Exercise;
    import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Contact_Update {


    public static void main(String[] args) {
        String myID = "3";
        String newName = "summer";
        try {   
            File myObj = new File("contact.txt");
            Scanner myReader = new Scanner(myObj);
            boolean found = false;
            while (myReader.hasNextLine()) {
                String data = myReader.nextLine();
                //System.out.println(data);
                String[] lineSplit = data.split(";");
                String id = lineSplit[0];
                String name = lineSplit[1];
                if (id.equals(myID)) {
                    found = true;
                    break;
                }
            }
            myReader.close();
            if (found == true) {
                // copy content to tmp.txt
                FileWriter myWriter = new FileWriter("temp.txt", true);
                File newFile = new File("contact.txt");
                Scanner newReader = new Scanner(newFile);
                while (newReader.hasNextLine()) {
                    String data = newReader.nextLine();
                    String[] lineSplit = data.split(";");
                    String id = lineSplit[0];
                    String name = lineSplit[1];
                    if (id.equals(myID)) {
                        myWriter.write(myID+";"+newName + "\n");
                    } else {
                        myWriter.write(data + "\n");
                    }
                }
                newReader.close();
                myWriter.close();
                // remove file
                File fileToRemove = new File("contact.txt");
                fileToRemove.delete();
                // rename file
                File file1 = new File("temp.txt");
                File file2 = new File("contact.txt");
                boolean success = file1.renameTo(file2);
                if(success)
                System.out.println("Record: " + myID + " Updated");
            } else {
                System.out.println("Record: " + myID + " Not found");
            }
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}


    

