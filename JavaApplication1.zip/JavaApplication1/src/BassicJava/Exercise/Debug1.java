
package BassicJava.Exercise;

public class Debug1 {
    public static void main(String arg [] ){
        //Input
        int letterCount = 0; 
        String strText = "Debugging";
       char letter = ' ';
        //Process
        for(int i=0; i<strText.length(); i++)
        {
            letter = strText.charAt(i);
            if (letter == 'g')
            {
                letterCount++;
                
            }
            
            
        }//output
        System.out.println("G appears :"+ letterCount+"time");
                
    }
    
}
