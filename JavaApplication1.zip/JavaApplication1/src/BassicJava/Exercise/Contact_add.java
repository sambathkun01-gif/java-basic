package BassicJava.Exercise;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
public class Contact_add {
    public static void main (String [] args){
        
        Scanner myScanner = new Scanner (System.in);
        System.out.println("ID: ");
        String myID = myScanner.nextLine();
        System.out.println("Name: ");
        String myName = myScanner.nextLine();
        try {
            FileWriter myWriter = new FileWriter("contact.txt", true);
            myWriter.write(myID + ";"+ myName + "\n");
            myWriter.close();
            System.out.println("contact added to file.");
        }catch (IOException e){
            e.printStackTrace();
        }
    }
    
}
