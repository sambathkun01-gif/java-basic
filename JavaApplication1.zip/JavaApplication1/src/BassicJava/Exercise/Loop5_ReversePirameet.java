
package BassicJava.Exercise;
import java.util.Scanner;
public class Loop5_ReversePirameet {
    public static void main(String [] args){
    Scanner scanner = new Scanner (System.in);
    System.out.print("Enpout your number :");
    int rows = scanner.nextInt();
    for (int i = 1; i <= rows; i++) {
            for (int j = 1; j <= i-1; j++){
                System.out.print(" ");
            }
            for (int k =0; k <=rows-i; k++  ) {
                System.out.print("* ");
            }
            System.out.println();
        }
    }
    
}
