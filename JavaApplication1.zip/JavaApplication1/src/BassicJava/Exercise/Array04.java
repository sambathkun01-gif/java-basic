package Bassicjava.Exercise;
import java.util.Scanner;
public class Array04{
    public static void main (String [] args){
        Scanner scanner = new Scanner (System.in);
        System.out.print ("Enter student Name: ");
        String name = scanner.nextLine();
        System.out.print ("Enter student ID:");
        int id = scanner.nextInt();
        
        String student [] = {"Makara", "Seyha","Kanha","Tola"};
        for(int i=0; i<student.length; i++){
            if (name.equals(student [i])){
                System.out.println(name + "is found");
            }
        }
        int [] student_ids = {5,10,15,20,25,30};
        for (int i=0; i<student_ids.length; i++){
            if (id == student_ids [i]){
                System.out.println(id +" is found." );
            }
        }
        
    }
}