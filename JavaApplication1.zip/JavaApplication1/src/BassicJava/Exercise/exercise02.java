package Bassicjava.Exercise;
import java.util.Scanner;
public class exercise02{
    public static void main (String [] args ){
     
        Scanner sambath = new Scanner(System.in);
        double num;
        double num1;
        double total=0 ;
        
        System.out.print ("your number1 :");
         num =sambath.nextInt();
         
        System.out.print ("your number2 :");
         num1 = sambath.nextInt();
         
        System.out.print ("your oparator :");
        String   out = sambath.next();
        char output = out.charAt(0);
        switch (output){
            case '+': total = num + num1;
            break;
            case '-': total= num - num1;
            break;
            case '/': total= num / num1;
            break;
            case '*': total = num * num1;
            break;  
        } 
         System.out.println (total);
        
        
        
    }
}