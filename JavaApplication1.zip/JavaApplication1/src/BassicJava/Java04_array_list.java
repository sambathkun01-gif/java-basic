package BassicJava;
import java.util.ArrayList;
import java.util.Collections;
public class Java04_array_list {
    public static void main(String [] args){
        ArrayList<String> cars = new ArrayList<String>(); 
        cars.add("voilvo");
        cars.add("BMW");
        cars.add("ford");
        cars.add("Mazda");
        Collections.sort(cars);
        for(String i : cars){
            System.out.println (i);
        }
    }
    
}
