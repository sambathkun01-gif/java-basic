package Bassicjava;

public class Class22_foreach {

    public static void main(String[] args) {
        String[] cars = {"vovlo", "BMW", "Ford", "Mazda"};
        for (String car : cars) {
            System.out.println(car);
        }

        int[] scores = {50, 90, 80, 40};
        for (int score : scores) {
            System.out.println(score);
        }
        System.out.println(cars[1]);
        for (int i = 0; i < cars.length; i++) {

            System.out.println(cars[3]);
        }
    }
}
