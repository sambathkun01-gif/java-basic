package Bassicjava;
public class Class26_loop_in_function{
    public static void main(String [] args){
        int myvar = summation (4);
        System.out.println(myvar);
    }
    public static int summation (int n){
        int sum = 0;
        for (int i = 1;i<= n; i++){
            sum += i;
        }
        return sum;
    }
}