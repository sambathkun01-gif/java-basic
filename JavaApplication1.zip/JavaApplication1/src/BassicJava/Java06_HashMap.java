
package BassicJava;

import java.util.HashMap;
public class Java06_HashMap {
    public static void main(String [] args){
        HashMap <String , String> capitalcities = new HashMap <String , String>();
        
        capitalcities.put("english", "London");
        capitalcities.put("Germany", "Berlin");
        capitalcities.put("Norway","oslo");
        capitalcities.put("USA", "WasinTon.DC");
        capitalcities.put("Cambodia", "Phnom penh");
        System.out.println(capitalcities);
        System.out.println(capitalcities.get("Cambodia"));
        capitalcities.remove("USA");
        System.out.println(capitalcities);
        
    }
    
}
