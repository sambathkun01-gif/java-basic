package BassicJava;
public class Class13_oprator{
    public static void main(String [] args){
        //Comparison Operator
        int x = 10;
        int y = 12;
        System.out.println(x ==y);//false
        System.out.println(x !=y);//true
        System.out.println(x >y);//false
        System.out.println(x <y);//true
        System.out.println(x <=y);//true
        System.out.println(x >=y);//false
        
    }
}
        

