package BassicJava;
public class Class08_boolean{
    public static void main (String [] args){
        boolean isJavaFun = true;
        boolean isFirstTasty = false;
        boolean pass = true;
        System.out.println(!pass);
        System.out.println(isJavaFun);
        System.out.println(isFirstTasty);
        
        
    }
}