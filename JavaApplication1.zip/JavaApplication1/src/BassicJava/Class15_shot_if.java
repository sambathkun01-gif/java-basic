package BassicJava;

public class Class15_shot_if {

    public static void main(String[] args) {
        //Short Hand if...Else
        int exam, project;
        String resultExam, resultProject;
        exam = 50;
        project = 40;
        resultExam = (exam >= 50) ? "pass" : "false";
        System.out.println("Exam is :" + resultExam);
        resultProject = (project >=50) ? "pass" : "false";
        System.out.println("project is :" + resultProject);
    }
}
