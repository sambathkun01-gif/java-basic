package Bassicjava;
public class Class27_Array{
    public static void main(String []args){
        String mycar = "MG";
        String mycars [] = {"volvo","BMW","Ford","Mazda"};
        int [] myNums = {30,10,50,90};
     
        
        mycars [0] = "Toyota";
        myNums [0] = 80;
        
        System.out.println(mycar);
        System.out.println(mycars[2]);
        System.out.println(myNums[2]);
    }
}
