package BassicJava;

public class Class04_varibale {

    public static void main(String[] args) {
        char myLetter = 'S';
        System.out.println(myLetter);

        String myName = "   sambath";
        System.out.println(myName);

        int myNum = 15;
        System.out.println(myNum);

        int myNum2;
        myNum2 = 15;
        System.out.println(myNum2);

        int myNum3 = 15;
        myNum3 = 20;
        System.out.println(myNum3);

        final int myNum4 = 16;
        // myNum4 = 16 //error
        System.out.println(myNum4);

        float myFloatNum = 5.99f;
        double myDouble = 5.99d;
        boolean myBool = true;
        System.out.println(myFloatNum);
        System.out.println(myDouble);
        System.out.println(myBool);

    }
}
