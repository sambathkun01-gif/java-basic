package BassicJava;
import java.util.Arrays;

public class Class29_copy_Array {
    
    public static void main(String[] args) {
        int[] sourceArray = {2, 6, 8, 4, 1};
        
        int[] targetArray = new int[sourceArray.length];
        
        for (int i = 0; i < sourceArray.length; i++) {
            targetArray[i] = sourceArray[i];
        }
        System.out.println(Arrays.toString(sourceArray));
       // System.out.println(Arrays.toString(targetArray));
    }

}
