package BassicJava;
import java.io.File;
public class java5_delete {
    public static void main(String [] args){
        File myobj = new File ("test.txt");
        if (myobj.delete()){
            System.out.println("Delete the file:"+ myobj.getName());
        }else {
            System.out.println("Filed to delete the file.");
        }
    }
    
}
