package Bassicjava;

public class Class20_do_while {

    public static void main(String[] args) {
        int j = 0;
        do {
            System.out.println("World" + j);
            ++j;
        }while (j<5);

    }
}
