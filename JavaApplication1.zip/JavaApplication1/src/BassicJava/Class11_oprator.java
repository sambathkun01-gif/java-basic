package Bassicjava;
public class Class11_oprator{
    public static void main (String [] args){
        double a, b, result1, result2, result3, result4, result5;
        //Arithmetic operators
        a = 103;
        b = 50;
        result1 = a + b;
        result2 = a-b;
        result3 = a*b;
        result4 = a/b;
        result5 = a%b;
        
        System.out.println(result1);
        System.out.println(result2);
        System.out.println(result3);
        System.out.println(result4);
        System.out.println(result5);
        b++;
        a--;
        System.out.println(a);
        System.out.println(b);


        
    }
    
}