
package BassicJava;

import java.util.HashSet;
public class Java12_HashSet {
    public static void main (String [] args){
        HashSet<Integer> number = new HashSet<Integer>();
        number.add(4);
        number.add(7);
        number.add(8);
        
        for (int i= 1; i<=10; i++){
            if(number.contains(i)){
                System.out.println(i+"Was found in the set" );
            }else{
                System.out.println(i+"Was not found in the set");
            }
        }
    }
    
}
