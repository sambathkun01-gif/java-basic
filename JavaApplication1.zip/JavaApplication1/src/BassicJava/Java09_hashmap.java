
package BassicJava;

import java.util.HashMap;
public class Java09_hashmap {
    public static void main(String [] arge){
        HashMap<String,String> capitalcities = new HashMap<String,String>();
        capitalcities.put("English", "London");
        capitalcities.put("Norway", "Oslo");
        capitalcities.put("USA", "WasintonD.C");
        capitalcities.put("Cambodia", "Phnom phen");
        capitalcities.remove("Cambodia");
        for (String i : capitalcities.keySet()){
            System.out.println("Key"+i+"value"+capitalcities.get(i));
        }
    }
    
}
