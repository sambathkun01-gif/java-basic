package BassicJava;
public class Class06_datatype{
    public static void main(String[] args){
        int myNum = 5;
        float myFloatNum = 5.99f;
        double myDoubleNum = 5.99d;
        char myLetter = 'S';
        String myText = "sambath";
        boolean myBool = true; //true,false
        //System.out.print(5 + 5.3);
        int a = 4;
        int b = 3;
        System.out.println(a+b);
        
    }
}