
package BassicJava;

class  Dog {
    // state ==> name age color 
    public String name =  "Ki Ki"; 
    public int age = 23;
    public String color = "Brown";
    
    // behavior ==> Brak Eat Sleep
    public void Brak(){
        System.out.println("Wooo wooo");
    }
    public void Eat(){
        System.out.println("chicken");            
    }
    public void Sleep(){
        System.out.println("Zzzzzzzzz");
    }
}
public class Oop13_StateAndBehaior {
    public static void main(String []  args){
        System.out.println("\n---------------------------------\n");
        Dog dog1 = new Dog ();
        dog1.Eat();
        dog1.Sleep();
        dog1.Brak();
        System.out.println("name:"+dog1.name);
        System.out.println("age:"+dog1.age);
        System.out.println("color:"+dog1.color);
        System.out.println("\n---------------------------------\n");
    }
}
