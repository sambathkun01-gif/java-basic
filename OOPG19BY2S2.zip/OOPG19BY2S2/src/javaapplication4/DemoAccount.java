/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class DemoAccount {

    public static void main(String[] args) throws ParseException {
        Scanner sc = new Scanner(System.in);
        // Create date format for easy date creation
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        System.out.print("Date accountCreation :");
        Date accountCreation = dateFormat.parse(sc.nextLine());
        System.out.print("initialdeposit:");
        double a = sc.nextDouble();
        Account myAccount = new Account(accountCreation, "ABS-23222", a);

      
        Date depositDate = dateFormat.parse("11-02-2002");
        System.out.print("deposit:");
        double b = sc.nextDouble();
        myAccount.deposit(depositDate, b);

        
        Date withdrawDate = dateFormat.parse("10-04-2034");
        System.out.print("withdraw :");
        double c = sc.nextDouble();
        myAccount.withdraw(withdrawDate, c);

        
        Date interestDate = dateFormat.parse("22-04-2008");
        System.out.print("interest :");
        double d = sc.nextDouble();
        myAccount.interest(interestDate, d);

        // Display account information
     
        System.out.println("Account Number: " + myAccount.getAccountNumber());
        System.out.printf("Current Balance: $%.2f\n", myAccount.getRecordBalance());

    }

}
