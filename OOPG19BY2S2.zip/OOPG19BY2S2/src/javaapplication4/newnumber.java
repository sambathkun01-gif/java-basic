
package javaapplication4;

import java.util.Scanner;
public class newnumber {
    public static void main(String [] args){
         Scanner scanner = new Scanner(System.in);

        // បញ្ចូលលេខអំណានចាស់ និងអំណានថ្មី
        System.out.print("បញ្ចូលលេខអំណានចាស់: ");
        int oldReading = scanner.nextInt();
        System.out.print("បញ្ចូលលេខអំណានថ្មី: ");
        int newReading = scanner.nextInt();

        int usage = newReading - oldReading;
        int payment = 0;

        if (usage <= 200) {
            payment = usage * 610;
        } else if (usage <= 300) {
            payment = (200 * 610) + (usage - 200) * 720;
        } else if (usage <= 500) {
            payment = (200 * 610) + (100 * 720) + (usage - 300) * 730;
        } else if (usage <= 700) {
            payment = (200 * 610) + (100 * 720) + (200 * 730) + (usage - 500) * 950;
        } else {
            payment = (200 * 610) + (100 * 720) + (200 * 730) + (200 * 950) + (usage - 700) * 1050;
        }

        int remainder = payment % 100;

        if (remainder != 0 && remainder < 100) {
            System.out.println("ចំនួនប្រាក់ត្រូវបង់: " + (payment - remainder) + " ៛");
            System.out.println("ចំនួន " + remainder + " ៛ នឹងត្រូវបញ្ចូលក្នុងវិក័យប័ត្រខែក្រោយ។");
        } else {
            System.out.println("ចំនួនប្រាក់ត្រូវបង់: " + payment + " ៛");
        }


    }
    
    }
    

