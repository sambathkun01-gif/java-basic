package javaapplication4;

public class ADemo {

    public static void main(String[] args) {
        A.a = 10;
        System.out.print(A.getSum());
        A ab = new A();
        System.out.print(ab.getpower());

    }

}
