
package javaapplication4;


public class JavaApplication4 {

    public static void main(String[] args) {
        // TODO code application logic here
        int a= 10 , b=5;
        int c = a++ * --b;
        
        System.out.println("a" +a +"c"+c);
        //incrieament i++ <=> i = i+1 <=> i-=1 /// ++i , i++ ,--i , i-- //បើសញ្ញាណាមូយដែលនៅមុខនោះវានិងគណនាមុន(--i,++i)
        
        //this is format
        
        System.out.println(String.format("123%",args));
    }
    
}
