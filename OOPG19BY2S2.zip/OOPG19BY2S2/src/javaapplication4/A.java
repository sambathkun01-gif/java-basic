/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;
/**
 *
 * @author Asus
 */
public class A {
    
    static int a;
    private static int b;
    private  int c;
    public  void setc(int c){
       this.c = c;
    }
    
    public int getpower (){
        return c*c;
    }
    public static int getSum(){
        return a+b;
    }
    
}
