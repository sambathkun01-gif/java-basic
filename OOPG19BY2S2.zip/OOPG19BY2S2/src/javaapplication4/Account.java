/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Account {
  
    private String accountNum;
    private double accountbalance;
    private double withdrawamount;
    private double depositamount;
    private double interestamount;
    private List<AccountHistory> trans;

    public Account() {
        this.accountNum = "";
        this.accountbalance = 0;
        this.withdrawamount = 0;
        this.depositamount = 0;
        this.interestamount = 0;
        this.trans = new ArrayList<>();//trans is instiated to object of ArrayList
    }

    public Account(Date transdate, String accountNum, double initialDeposit) {
        this();
        this.accountNum = accountNum;
        this.deposit(transdate, initialDeposit);
    }

    public String getAccountNumber() {
        return accountNum;
    }

    public double getRecordBalance() {
        return accountbalance;
    }

    public void deposit(Date transdate, double amount) {
        accountbalance += amount;
        depositamount += amount;
        trans.add(new AccountHistory(transdate, "deposit", amount));
    }

    public void withdraw(Date transdate, double amount) {
        if (amount > accountbalance) {
            throw new IllegalArgumentException("Insufficient funds");
        }
        accountbalance -= amount;
        withdrawamount += amount;
        trans.add(new AccountHistory(transdate, "withdrawal", amount));
        
    }

    public void interest(Date transdate, double interestAmount) {
        accountbalance += interestAmount;
        interestamount += interestAmount;
        trans.add(new AccountHistory(transdate, "interest", interestAmount));
    }
}


    
