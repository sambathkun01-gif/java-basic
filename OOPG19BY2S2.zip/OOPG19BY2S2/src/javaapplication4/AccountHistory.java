/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4;

import java.util.Date;

/**
 *
 * @author Asus
 */
public class AccountHistory {

    private Date transdate;
    private double withdrawal;
    private double deposit;
    private double interest;
    private String transname;

    public AccountHistory(Date transdate, String transname, double amount) {
        this.transdate = transdate;
        this.transname = transname;
        
        // Initialize all transaction types to 0
        this.withdrawal = 0.0;
        this.deposit = 0.0;
        this.interest = 0.0;
        
        // Set appropriate field based on transaction type
        switch(transname.toLowerCase()) {
            case "withdrawal":
                this.withdrawal = amount;
                break;
            case "deposit":
                this.deposit = amount;
                break;
            case "interest":
                this.interest = amount;
                break;
        }
    }

    public Date getTransactionDate() {
        return transdate;
    }

    public String getTransactionName() {
        return transname;
    }

    public double getAmount() {
        switch(transname.toLowerCase()) {
            case "withdrawal": return -withdrawal;
            case "deposit": return deposit;
            case "interest": return interest;
            default: return 0.0;
        }
    }
}

