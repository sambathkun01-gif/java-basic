
package javaapplication4.SimplePack;
import javax.swing.JOptionPane;
public class Taxation {
    public static void main(String[] args) {
        double salary, taxpay, netSalary = 0;
        salary = Double.parseDouble(JOptionPane.showInputDialog("Please input salary"));
        if (salary > 12500000){
            taxpay = (5000000*0.5) + (3000000*0.1)+(3000000 * 0.15)+(4500000 * 0.2)+((salary - 12500000)*0.25);
        }
        else if (salary > 8000000){
            taxpay = (5000000*0.05)+ (3000000*0.1)+(3000000 * 0.15)+((salary - 8000000)*0.15);
        }
        else if (salary > 5000000){
            taxpay = (5000000*0.05)+ (3000000*0.1)+((salary - 5000000)*0.15); 
        }
        else if (salary > 2000000){
             taxpay = (5000000*0.05)+((salary - 2000000)*0.1);
        }
        else if (salary > 1500000){
            taxpay = ((salary - 1500000)*0.05);
        }
        else {
            taxpay = salary*0;
        }
        netSalary = salary - taxpay;
        String Str = String.format("Salary = %10.2f Riel\nTaxation = %10.2f Riel\nNet Salary = %10.2f Riel\n", salary,taxpay,netSalary);
        
        JOptionPane.showMessageDialog(null, Str);
    }
    
}
