/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4.SimplePack;

import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class CharacterCountDemo {
    public static void main(String [] args){
        CharacterCount n = null ;
    String st = JOptionPane.showInputDialog("Input Sentence : ");
//    chc = new CharacterCount(JOptionPane.showInputDialog("Input Sentence : "));
    JOptionPane.showMessageDialog(null,n.getCharacterCountIngnoreSpace());
    }
}
    

