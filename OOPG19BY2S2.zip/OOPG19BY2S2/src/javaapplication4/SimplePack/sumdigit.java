package javaapplication4.SimplePack;

import java.util.Scanner;

public class sumdigit {

    public static void main(String[] args) {
        int n, sum = 0;
        Scanner sc = new Scanner(System.in);
        System.out.print("Please input number : ");
        n = sc.nextInt();
        System.out.print(n + " = ");
        while (n > 0) {
            sum += n % 10;
            System.out.print(n % 10);
            n /= 10;
            if (n == 0) {
                System.out.print(" = ");
            } else {
                System.out.print(" + ");
            }
        }
        System.out.println(sum);
    }
}
