/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4.SimplePack;

/**
 *
 * @author Asus
 */
public class CircleDemo {
    public static void main(String []args){
        Circle c1 = new Circle(12);
       
        System.out.println(c1.radius);
        System.out.println("Number:"+Circle.getNumberOfObject());
        System.out.println("getArea :"+c1.getArea());
        Circle c2 = new Circle(10);
        System.out.println(c2.radius);
        System.out.println("Number:"+Circle.getNumberOfObject());
        System.out.println("getArea :"+c2.getArea());
        
    }
    
}
