
package javaapplication4.SimplePack;

import java.util.Scanner;


public class reversedigit {
    public static void main(String []args){
        int n, rev = 0;
        Scanner sc = new Scanner (System.in);
        System.out.println("enter number: ");
        n = sc.nextInt();
        System.out.println(n+"Reverse to");
        while(n > 0){
            rev +=n %10;
            n/=10;
            if(n>0) rev *=10;
        }
        System.out.println(rev);
    }
    
}
