package javaapplication4.SimplePack;

import java.util.Scanner;

public class GuessPhonNumber {

    public static void main(String[] args) {

        int phone, sum = 0;
        String st = "";
        Scanner sc = new Scanner(System.in);
        System.out.print("Plese input your phone number: ");
        phone = sc.nextInt();
        st = "Phone Number :" + phone + "\n";
        // System.out.println("Phone Number :" + phone +"\n");
        while (phone > 0) {
            sum += phone % 10;
            phone /= 10;
            if (sum >= 10) {
                sum -= 9;
            }
        }
        switch (sum) {
            case 0:
                st += "good";
                break;
            case 1:
                st += "A good";
                break;
            case 2:
                st += "B good";
                break;
            case 3:
                st += "C good";
                break;
            case 4:
                st += "D good";
                break;
            case 5:
                st += "F good";
                break;
            case 6:
                st += "G good";
                break;
            case 7:
                st += "H good";
                break;
            case 8:
                st += "I good";
                break;
            case 9:
                st += "J good";
                break;
        }
        System.out.println(st);
    }
}
