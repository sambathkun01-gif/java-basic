package javaapplication4.SimplePack;

import javax.swing.JOptionPane;
public class ElectricBill {
    public static void main(String [] args){
      int oldnum,newnum, usage = 0;
      double price, bill = 0 ,nextbill = 0;
      do{
         oldnum = Integer.parseInt(JOptionPane.showInputDialog("Please input old number:"));
         newnum = Integer.parseInt(JOptionPane.showInputDialog("Please input new number:"));
      }while(oldnum > newnum);
      usage = newnum - oldnum;
      price = usage > 1000? 1050:
              usage > 700? 950:
              usage > 500? 840:
              usage > 300? 730:
              usage > 200? 720:610;
      bill = usage * price;
      nextbill = bill % 100;
      bill -= nextbill;
     // bill = bill- nextbill;
     
//      System.out.println("price :"+price);
//      System.out.println("bill :"+bill);
//      System.out.println("usage :"+usage);
//      System.out.println("nextbill :"+nextbill);
//       JOptionPane.showMessageDialog(null, 
//                "Usage: " + usage + " kW\n" +
//                "Rate: " + price + " Riels\n" +
//                "Total Bill: " + bill + " Riels");
System.out.println(String.format("Electricity Usage : %10d kw\n"+
         "Unit Price         : %10.2f R\nBilling Amount     : %10.2f R\n"+
         "Next Billing Amoun : %10.2f R", usage,price,bill,nextbill));
       
   
      
   } 
}
        
