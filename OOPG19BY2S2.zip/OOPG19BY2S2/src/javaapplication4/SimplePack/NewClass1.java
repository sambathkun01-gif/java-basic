/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4.SimplePack;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class NewClass1 {
    public static void main(String [] args){
        Scanner sc = new Scanner(System.in);
        System.out.print("please :");
        String st = sc.next();
        
        String s1 = st;
        System.out.println(s1.length());
          
        
        
      
    }
    
}
