/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package javaapplication4.SimplePack;

/**
 *
 * @author Asus
 */
public class CharacterCount {
    String st;
    public CharacterCount(){}
    public CharacterCount(String st){
        this.st=st;
    }
    public void setString(String st){
        this.st=st;
    }
    public String toString (){
        return this.st;
    }
    public int getCharCount(){
        return this.st.length();
    }
    public int getCharacterCountIngnoreSpace(){
        int count = 0;
        char[] ch = st.toCharArray();
        for(char c : ch){
            if(c != ' ')count++;
        }
        return count;
    }
        
  
    
}
