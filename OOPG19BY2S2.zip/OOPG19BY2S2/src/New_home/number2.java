package New_home;

import javax.swing.JOptionPane;
public class number2 {
    public static void main(String [] args){
    String n = JOptionPane.showInputDialog("Enter number:");
        if (n != null && !n.isEmpty()) {
            try {
                int num = Integer.parseInt(n);
                int rev = 0;
                while (num > 0) {
                    rev = rev * 10 + num % 10;
                    num /= 10;
                }
                JOptionPane.showMessageDialog(null, "Reversed: " + rev);
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Invalid input.");
            }
        }
    }
}
