/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New_home;

import java.text.DecimalFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;


/**
 *
 * @author Asus
 */
public class LoanCalulator {
    private double loanAmount;
    private double yir;
    private int noy ;

 public  LoanCalulator(){
    loanAmount = 0;
    yir = 0;
    noy = 0;
 }
 public LoanCalulator(double amount, double yir,int noy){
    this.loanAmount=amount;
    this.yir=yir;
    this.noy=noy;
 }
 public void setLoanAmount(double amount){
     this.loanAmount=amount;
 }
 public double getMonthlyPay(){
  double monthlyRate = yir /12/100;
  int numberOfPayment = noy*12;
  return(loanAmount * monthlyRate)/(1-Math.pow(1+monthlyRate,-numberOfPayment));
 }
 public double getTotalInterestPay(){
     return getMonthlyPay()*noy*12-loanAmount;
 }
public  void showSchedule(){
    double balance = loanAmount;
    double monthlyRate = yir/12/100;
    double monthlyPay = getMonthlyPay();
    int totalMonths = noy*12;
    
    DecimalFormat df = new DecimalFormat("#.00");
    DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd-MM-yy");
    LocalDate date = LocalDate.now();

        System.out.println("No\tDate\t\tMonthlyPayment\tInterest\tPrincipal\tBalance");

        for (int i = 1; i <= totalMonths; i++) {
            double interest = balance * monthlyRate;
            double principal = monthlyPay - interest;
            balance -= principal;

            System.out.println(i + "\t" + dtf.format(date) + "\t" +
                    df.format(monthlyPay) + "\t\t" +
                    df.format(interest) + "\t\t" +
                    df.format(principal) + "\t\t" +
                    df.format(balance));

            date = date.plusMonths(1);
        }
} 
}

