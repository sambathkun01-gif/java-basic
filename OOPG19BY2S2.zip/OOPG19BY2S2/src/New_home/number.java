package New_home;
import javax.swing.JOptionPane;
public class number {
    public static void main(String [] args){
     String n = JOptionPane.showInputDialog("Number:");
        if (n != null && !n.isEmpty()) { 
            int sum = 0;
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < n.length(); i++) {
                if (Character.isDigit(n.charAt(i))) {
                    int digit = Character.getNumericValue(n.charAt(i));
                    sum += digit;
                    sb.append(digit).append(i < n.length() - 1 ? " + " : "");
                } else {
                    JOptionPane.showMessageDialog(null, "Invalid input.");
                    return; 
                }
            }
            JOptionPane.showMessageDialog(null, sb.append(" = ").append(sum));
        }
    
    }
}
