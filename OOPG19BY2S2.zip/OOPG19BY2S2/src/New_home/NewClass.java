/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New_home;

import java.util.Date;

/**
 *
 * @author Asus
 */
public class NewClass {
    


    private int id;
    private String last_name;
    private String first_name;
    private String gender;
    private Date birthdate;

    // Constructor
    public NewClass(int id, String last_name, String first_name, String gender, Date birthdate) {
        this.id = id;
        this.last_name = last_name;
        this.first_name = first_name;
        this.gender = gender;
        this.birthdate = birthdate;
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Date getBirthdate() {
        return birthdate;
    }

    public void setBirthdate(Date birthdate) {
        this.birthdate = birthdate;
    }

    @Override
    public String toString() {
        return "ID: " + id +
                "\nLast Name: " + last_name +
                "\nFirst Name: " + first_name +
                "\nGender: " + gender +
                "\nBirthdate: " + birthdate;
    }


    public static void main(String[] args) {
        // Create a Person instance using java.util.Date
        NewClass person = new NewClass(
            1,
            "Doe",
            "John",
            "Male",
            new Date(90, 4, 15) // May 15, 1990 (Note: year 90 = 1990)
        );

        // Print person details using toString()
        System.out.println("Person Details:");
        System.out.println(person);
    }
}
    

