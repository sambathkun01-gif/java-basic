
package New_home;

import java.text.SimpleDateFormat;
//import java.util.Date;
import java.util.*;

public class Person {
    private int id;
    private String f_name;
    private String l_name;
    private String gender;
    private String phone;
    private String address;
    private Date birthdate;
    private SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-YYYY");
    public Person(){} 
    public Person (int id,String f_name,String l_name, String gender,String phone ,String address,Date birthdate){
         this.id = id;
         this.f_name = f_name;
         this.l_name = l_name;
         this.gender = gender;
         this.phone = phone;
         this.address = address;
         this.birthdate = birthdate;
     }
     public void setID(int id){
         this.id = id;
     }
      public void setFirstName(String f_name){
       this.f_name = f_name;
   }
   public void setLastName(String l_name){
       this.l_name = l_name;
   }
   public void setGender(String gender){
       this.gender = gender;
   }
   public void setPhone(String phone){
       this.phone = phone;
   }
   public void setaddress(String address){
       this.address = address;
   }
   public void setBirthdate(Date birthdate){
       this.birthdate = birthdate;
   } 
   
   public int  getID (){
       return this.id;
   }
   public String getFristName(){
       return this.f_name;
   }
   public String getLastName(){
       return this.l_name;
   }
    public String getGender (){
       return this.gender;
   }
   public String getPhone (){
       return this.phone;
   }
   public String getaddress (){
       return this.address;
   }
   public Date getBirthdate(){
       return this.birthdate;
   }
  
    public String showinof() {
        return "ID: " + id +
                "\nFull Name: " + f_name+"​​ "+l_name+
                "\nGender: " + gender +
                "\nPhone:"+phone+
                "\nAddress:"+address+
                "\nBirthdate: " + sdf.format(birthdate);
    }
   
}
