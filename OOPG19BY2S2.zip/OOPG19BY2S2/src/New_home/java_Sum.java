package New_home;

import java.util.Scanner;

public class java_Sum {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your number:");
        int num = scanner.nextInt();
        int sum = 0;

        while (num != 0) {
            sum += num % 10; 
            num /= 10;
        }

        System.out.println(sum);
    }

}
