
package New_home;

import java.util.Scanner;
public class Guse_Number {
    public static void main(String [] args){
        Scanner number = new Scanner (System.in);
        System.out.print("Please Enter your number: ");
        int num = number.nextInt();
         int sum = 0;

        while (num != 0) {
            sum += num % 10; 
            num /= 10;
        }
        System.out.println(sum);
        String result; 
        switch (sum){
            case 1 :
                result = "Good day";
                break;
            case 2 :
                result = "life is Good";
                break;
            case 3 :
                result = "You miss her/his";
                break;
            case 4 :
                result = " Life is badly";
                break;
            case 5 : 
                result = "Good job";
                break;
            default:
                result = "Very Good";
                
        }
        System.out.print(result);
       
    }
    
}
