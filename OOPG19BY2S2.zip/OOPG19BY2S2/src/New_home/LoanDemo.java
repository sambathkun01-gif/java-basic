/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New_home;

import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class LoanDemo {
    public static void main(String [] args){
        Scanner sca = new Scanner (System.in);
        System.out.print("Please Inter amount :");
        int amount = sca.nextInt();
        System.out.print("Please Inter yir :");
        int yir = sca.nextInt();
        System.out.print("Please Inter noy :");
        int noy = sca.nextInt();
        
        LoanCalulator loan = new LoanCalulator(amount,yir,noy);
        System.out.println("Monthly Payment : " + loan.getMonthlyPay());
        System.out.println("Total Interest : " + loan.getTotalInterestPay());
        System.out.println();

        loan.showSchedule();
    }
        
        
    }
    

