/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New_home.Assingment;

import OOP19BY2S2.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Account {
      //Data Fields
        private String accnum;
        private double accbalance;
        private double deposittamount;
        private double withdrawamoun;
        private double interestamount;
        private List<AccountHistory> trans;
        //Constructors
        public Account(){
            this.accnum = "";
            this.accbalance = 0;
            this.deposittamount = 0;
            this.withdrawamoun = 0;
            this.interestamount = 0;
            this.trans = new ArrayList<>();
            
        }
        public Account(Date startdate,String accnum, double amount){
           this.accnum = accnum;
           this.accbalance = amount;
           this.deposittamount = amount;
           this.withdrawamoun = 0;
           this.interestamount = 0;
           this.trans = new ArrayList<>();
           this.trans.add(new AccountHistory(startdate,"dposit",amount)); 
        }
        //method setAccountNumber
        public void setAccountNumber(String accnum){
            this.accnum = accnum;
        }
        //Methos gets
        public String getAccountNumber(){return this.accnum;}
        public double getBalance(){return this.accbalance;}
        public double getWithdrawAmount(){return this.withdrawamoun;}
        public double getDepositAmount(){return this.deposittamount;}
        public double getInterestAmount(){return this.interestamount;}
        public List<AccountHistory> getTransactionList(){return this.trans;}
        
       public void deposit(Date transdate,double amount){
            if (amount > 0){
                
                    this.accbalance += amount;
                    this.deposittamount += amount;
                    this.trans.add(new AccountHistory(transdate,"deposit",amount));
                }
                else System.out.println("Your Account is incorreect value!");   
            }
            
        
       public void withdraw(Date transdate, double amount){
           if (amount > 0){
               if(amount <= this.accbalance){
                   this.accbalance -= amount;
                   this.withdrawamoun += amount;
                   this.trans.add(new AccountHistory(transdate,"withdraw",amount));
               }else System.out.println("Your Account balance is not engough!");
           }else System.out.println("Your amoun is incorrect");
       }
        public void interest(Date transdate, double yir){
            double mir = yir / 1200;//105 = (10/100)/ 12 = 10/(100 * 12) = 10/1200
            this.accbalance += this.accbalance * mir;
            this.interestamount += this.accbalance * mir;
            this.trans.add(new AccountHistory(transdate,"interest",this.accbalance * mir));
    }

    Object getAccountNum() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

                      
            
            }
        


            
    

