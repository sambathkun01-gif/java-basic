/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package New_home.Assingment;

import OOP19BY2S2.*;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Date;

/**
 *
 * @author Asus
 */
public class FixedSaving extends Account {
    private Date startdate ;
    private Date enddate;
    private double yir;
    private boolean isActive;
    private String desacc;
 public  FixedSaving(){
  super();
 isActive = true;
 };
 public  FixedSaving (Date startdate , String accnum, int period, String desacc,double yir, double amount ){
     super(startdate,accnum,amount);
     this.startdate  = startdate;
     ZonedDateTime zdt = startdate.toInstant().atZone(ZoneId.systemDefault());
     LocalDate calendate = zdt.toLocalDate();
     calendate = calendate.plusMonths(period);
     this.enddate = Date.from(calendate.atStartOfDay(ZoneId.systemDefault()).toInstant());
     this.desacc=desacc;
     this.yir = yir;
     this.isActive=true;
 }
 public void setStateDate(Date startdate){
     this.startdate = startdate;
 }
 public void setMonthPeriod(int period){
     LocalDate calendate = this.startdate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
     calendate.plusMonths(period);
     this.enddate = Date.from(calendate.atStartOfDay(ZoneId.systemDefault()).toInstant());
 }
 public void setYearlyInterestRate(double yir){
     this.yir = yir;
 }
 public void setIsActive(boolean isActive){
     this.isActive = isActive;
 }
 public void setDestinationAccount(String desacc){
     this.desacc = desacc;
 }
 public Date getStateDate (){
     return this.startdate;
 }
 public Date getEndDate (){
     return this.enddate;
 }
 public double getYearlyInterestRate(){
     return this.yir;
 }
 public boolean getIsActive (){
     return this.isActive;
 }   
 public int getMonthPeriod(){
     LocalDate sdate = this.startdate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
     LocalDate edate = this.enddate.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
     return (int) ChronoUnit.MONTHS.between(sdate,edate);
 }
 
}
