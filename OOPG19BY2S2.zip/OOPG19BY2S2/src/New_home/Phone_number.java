package New_home;

import javax.swing.JOptionPane;

public class Phone_number {

    public static void main(String[] args) {
        int sum = 0;
        String input = String.valueOf(JOptionPane.showInputDialog("Please input number :"));

        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            sum += Character.getNumericValue(c);
//            System.out.print("Char number :" + c +"\n" ); 
        }
        //sum = 12;
        while (sum >= 10) {
            int lastsum = 0;
            while (sum > 0) {
                lastsum += sum % 10; //2
                sum /= 10;
            }// 1
            sum = lastsum;
        }
        System.out.println(sum);

        for (int k = input.length() - 1; k >= 0; k--) {
            char h = input.charAt(k);
            System.out.print(h);
        }

        switch (sum) {
            case 1:
                System.out.println("Mak you Phong!!");
                break;
            case 2:
                System.out.println("Not good!!");
                break;
            case 3:
                System.out.println("Bad!!");
                break;
            case 4:
                System.out.println("Supper bad!!");
                break;
            case 5:
                System.out.println("Very good!!");
                break;
            case 6:
                System.out.println("Mother fuck!!");
                break;
            case 7:
                System.out.println("Fuck you!!");
                break;
            case 8:
                System.out.println("Bitch!!");
                break;
            case 9:
                System.out.println("Go to hell!!");
                break;

        }

    }
}
