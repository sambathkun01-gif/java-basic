package New_home;

import java.util.Date;


public class PersonDemo {

    public static void main(String[] args) {
        
        Person person1 = new Person(
                1,
                "Kun",
                "Sambarth",
                "M",
                "01223444",
                "Phonh phen",
                new Date(2022, 02, 02));
        System.out.println(person1.showinof());
        System.out.println("--------------------------------------");
        Person person2;
        person2 = new Person(
                
                1,
                "Do",
                "Jo",
                "M",
                "01223444",
                "Phonh phen",
                new Date(0, 0, 0));
                
    }
}

