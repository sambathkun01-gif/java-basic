/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Asus
 */
public class Customer extends Person {
    private String cusId;
    private List<Account> acc;

    // Default constructor
    public Customer() {
        this.cusId = "";
        this.acc = new ArrayList<>();
    }

    // Constructor with parameters (add more Person fields if needed)
    public Customer(String cusId) {
        this.cusId = cusId;
        this.acc = new ArrayList<>();
    }

    public void setCustomerID(String cusId) {
        this.cusId = cusId;
    }

    public String getCustomerID() {
        return this.cusId;
    }

    public void setAccount(Account account) {
        this.acc.add(account);
    }

    public void updateAccount(String accNum, Account updatedAccount) {
        for (int i = 0; i < acc.size(); i++) {
            if (acc.get(i).getAccountNum().equals(accNum)) {
                acc.set(i, updatedAccount);
                return;
            }
        }
        System.out.println("Account with account number " + accNum + " not found.");
    }

    public Account getAccount(String accNum) {
        for (Account a : acc) {
            if (a.getAccountNum().equals(accNum)) {
                return a;
            }
        } 
        return null; // not found
    }

    public void deleteAccount(String accNum) {
        for (int i = 0; i < acc.size(); i++) {
            if (acc.get(i).getAccountNum().equals(accNum)) {
                acc.remove(i);
                return;
            }
        }
        System.out.println("Account with account number " + accNum + " not found.");
    }

    public List<Account> getAccountList() {
        return this.acc;
    }
    
}
