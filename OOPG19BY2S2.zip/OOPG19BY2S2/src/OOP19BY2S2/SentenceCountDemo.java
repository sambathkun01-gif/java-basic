/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

import OOP19BY2S2.SentenceCount;
import javax.swing.JOptionPane;

/**
 *
 * @author Asus
 */
public class SentenceCountDemo {
    public static void main(String [] args){
    SentenceCount sc;
    sc = new SentenceCount(JOptionPane.showInputDialog("Input Paragraph:"));
    JOptionPane.showMessageDialog(null,sc.wordCount());
    JOptionPane.showMessageDialog(null,sc.SentenCount());
    }
    
}
