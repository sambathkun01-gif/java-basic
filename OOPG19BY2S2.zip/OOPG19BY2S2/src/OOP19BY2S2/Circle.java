
package OOP19BY2S2;

public class Circle {
    double radius;//data file
    public void setRadius (double radius){ // Method set
        this.radius = radius;
    }
    public double getarea (){
        return Math.PI * Math.pow (this.radius, 2);
    }
    public double getPerimeter (){
        return Math.PI *this.radius*2;
    }
    
}
