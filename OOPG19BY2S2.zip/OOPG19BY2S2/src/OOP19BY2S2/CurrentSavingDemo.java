/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.*;
import java.util.Date;

/**
 *
 * @author Asus
 */
public class CurrentSavingDemo {
    public static void main(String [] args){
     Date ddate = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
 CurrentSaving cs = new CurrentSaving(ddate,"123",0.12,20);
 
 cs.deposit(ddate, 100);
 cs.withdraw(ddate, 50);
 
 System.out.println("======================================================");
 String str = "Start Date: "+ new SimpleDateFormat("dd/MM/yyyy").format(cs.getStartDate())+
                "\n Account Number: "+ cs.getAccountNumber()+ 
                 "\nAccount Balance: "+ cs.getBalance()+
                 "\nActive Account: " + cs.getIsActive();
 System.out.println(str);
 
    }
    
}
