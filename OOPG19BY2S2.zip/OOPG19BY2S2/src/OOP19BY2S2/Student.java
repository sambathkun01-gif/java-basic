package OOP19BY2S2;
import java.util.Date;
public class Student {
    // Declare date field as private access modifier
    private int id;
    private String l_name;
    private String f_name;
    private String gender;
    private Date birthdate;
    // create constructor 
    Student (){}
    public Student (int id , String f_name,String l_name, String gender, Date birthdate){
        this.id = id;
        this.f_name = f_name;
        this.l_name = l_name;
        this.gender = gender;
        this.birthdate = birthdate;
    }  
        
     //create Muthod set
    public void setID(int id){
        this.id = id;
    }
   public void setFirstName(String f_name){
       this.f_name = f_name;
   }
   public void setLastName(String l_name){
       this.l_name = l_name;
   }
   public void setGender(String gender){
       this.gender = gender;
   }
   public void setBirthdate(Date birthdate){
       this.birthdate = birthdate;
   }
   
   public int  getID (){
       return this.id;
   }
   public String getFristName(){
       return this.f_name;
   }
   public String getLastName(){
       return this.l_name;
   }
   public String getFullName(){
       return this.f_name +""+l_name;
   }
   public String getGender (){
       return this.gender;
   }
   public Date getBirthdate(){
       return this.birthdate;
   }
   
}

