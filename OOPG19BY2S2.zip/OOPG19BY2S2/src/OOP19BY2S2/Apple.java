package OOP19BY2S2;

public class Apple extends Fruit {
 
    private String taste;

    public Apple(String taste){
        this.taste = taste;
    }
    public String getTaste(){
        return "Sour";
    }
    @Override
    public String getColor(){
        return "pink";
    }
    
}

