/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2.ABankSysPack;

import OOP19BY2S2.AccountHistory;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 *
 * @author Asus
 */
public abstract class Account {
    private String accnum;
        private double accbalance;
        private double deposittamount;
        private double withdrawamoun;
        private double interestamount;
        private List<AccountHistory> trans;
   public Account(){
            this.accnum = "";
            this.accbalance = 0;
            this.deposittamount = 0;
            this.withdrawamoun = 0;
            this.interestamount = 0;
            this.trans = new ArrayList<>();
            
        }
    public Account(Date transdate,String accnum, double amount){
           this.accnum = accnum;
           this.accbalance = amount;
           this.deposittamount += amount;
           this.withdrawamoun = 0;
           this.interestamount = 0;
           this.trans = new ArrayList<>();
           this.trans.add(new AccountHistory(transdate,"dposit",amount)); 
           
        }
      public void setAccountNumber(String accnum){
            this.accnum = accnum;
        }
      protected void setInteresBalance(Date transdate, double amount){
          this.accbalance += amount;
          this.interestamount += 0;
          this.trans.add(new AccountHistory(transdate,"dposit",amount));
          
      }
      public String getAccountNumber(){return this.accnum;}
        public double getBalance(){return this.accbalance;}  
        public double getWithdrawAmount(){return this.withdrawamoun;}
        public double getDepositAmount(){return this.deposittamount;}
        public double getInterestAmount(){return this.interestamount;}
        public List<AccountHistory> getTransactionList(){return this.trans;}
        public abstract void interest(Date transdate);
}
