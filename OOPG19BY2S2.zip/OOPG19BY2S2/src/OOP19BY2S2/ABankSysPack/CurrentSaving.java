
package OOP19BY2S2.ABankSysPack;

import java.util.Date;


public class CurrentSaving extends Account {
     public CurrentSaving(){
     super();
     this.isactive = true;
     }
    public  CurrentSaving (Date stardate,String accnum,double yir,double amount){
        super(stardate,accnum,amount);
         this.startdate = stardate; 
         this.yir = yir;
         this.isactive = true;
         
    }
    public void setStartDate (Date startdate){
        this.startdate = startdate;
    }
    public void setYir (double yir){
        this.yir = yir/100;
    }
    public void setIsactive(boolean active){
        
        isactive = active;
    }
    public Date getStartDate(){
        return startdate;
    }
    public double getYir (){
        return yir;
    }
    public boolean getIsActive(){
         return isactive;
    }

    @Override
    public void interest(Date transdate) {
        double mir = this.yir / 2000.0;
    setInteresBalance(transdate , getBalance()* mir);
        
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    
    // Date menber
    private Date startdate;
    private double yir;
    private boolean isactive;
    
}
