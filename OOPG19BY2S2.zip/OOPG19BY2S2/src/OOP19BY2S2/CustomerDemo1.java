/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author Asus
 */
public class CustomerDemo1 {
    public static void main(String [] args) throws ParseException{
        Scanner sc = new Scanner(System.in);
        System.out.print("cusId : ");
        String cusId = sc.nextLine();
        System.out.print("Id : ");
        int id = sc.nextInt();
        System.out.print("");
        String ssn = sc.nextLine();
        System.out.print("fname: ");
        String fname = sc.nextLine();
        System.out.print("Lname : ");
        String lname = sc.nextLine();
        System.out.print("Gender: ");
        String gender = sc.nextLine();
        System.out.print("DateBirth : ");
        String sdf = sc.nextLine();
        System.out.print("Address : ");
        String address = sc.nextLine();
        System.out.print("Phone : ");
        String phone = sc.nextLine();
        System.out.print("Accnum : ");
        String accnum = sc.nextLine();
        System.out.print("Yir : ");
        double yir = sc.nextDouble();
        System.out.print("Amount : ");
        int amount = sc.nextInt();
        
        Customer1 cu;
        cu = new Customer1(cusId,id,ssn,fname,lname,gender,
                new SimpleDateFormat("dd-MM-yyy").parse(sdf),phone,address,
                 new CurrentSaving(Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()),
                        accnum,yir,amount));
        System.out.println("Customer ID    : " + cu.getCustomerID());
        System.out.println("Customer F_Name    : " + cu.getFristName());
        System.out.println("Customer L_Name    : " + cu.getLastName());
        System.out.println("Customer Gender    : " + cu.getGender());
        System.out.println("Customer Birth_Date    : " + new SimpleDateFormat("dd-MM-yyyy").format(cu.getBirthdate()));
        System.out.println("Customer Address    : " + cu.getaddress());
        System.out.println("Customer telephone    : " + cu.getPhone());
        
        for(Account ac : cu.getAccountList())
            if(ac instanceof CurrentSaving){
              CurrentSaving  cs = (CurrentSaving)ac;
                System.out.println("Account Number     : " + cs.getAccountNumber());
                System.out.println("Yearly Interest   : " + cs.getYir() + " %");
                System.out.println("balance Amount   : " + cs.getBalance()+"USD$");
            }else{
                FixedSaving fs = (FixedSaving) ac;
                System.out.print("uu"+fs.getAccountNumber());
                System.out.print("uu"+fs.getMonthPeriod());
                System.out.print("uu"+fs.getDepositAmount());
                System.out.print("uu"+fs.getYearlyInterestRate());
                System.out.print("uu"+fs.getBalance());
                
            }
        
//        CurrentSaving cs = (CurrentSaving) cu.getAccount("1234567");
//        System.out.println("Account Number     : " + cs.getAccountNumber());
//        System.out.println("Yearly Interest   : " + cs.getYir() + " %");
//        System.out.println("balance Amount   : " + cs.getBalance()+"USD$");
    }
    
}
