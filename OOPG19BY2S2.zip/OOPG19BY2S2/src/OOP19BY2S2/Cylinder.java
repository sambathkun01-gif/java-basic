package OOP19BY2S2;

public class Cylinder extends Circle {
    private double length;
    public void setLenght(double lenght){
        this.length = lenght;
    }
    public double getLength (){return this.length;} 
    public double getVolum(){
        return super.getarea() * this.length;
    }
}
