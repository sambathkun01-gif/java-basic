/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

/**
 *
 * @author Asus
 */
public class CastingTest {
   
    public static void main(String[] args) {
        Fruit fruit = new Grape(" "," ");  // Can change to new Apple()

        System.out.println("Color: " + fruit.getColor());

        if (fruit instanceof Apple) {
            Apple a = (Apple) fruit;
            System.out.println("Taste: " + a.getTaste());
        } else if (fruit instanceof Grape) {
            Grape g = (Grape) fruit;
            System.out.println("Taste: " + g.getTaste());
            System.out.println("Vitamin: " + g.getVitamin());
        } else {
            System.out.println("Unknown fruit");
        }
    }
}

            
    
    

