/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

/**
 *
 * @author Asus
 */
public class CylinderDemo {
    public static void main(String [] args){
        Cylinder cd= new Cylinder();
        cd.setRadius(5.1);
        cd.setLenght(1.5);
        System.out.print(cd.getVolum());
        
    }
    
}
