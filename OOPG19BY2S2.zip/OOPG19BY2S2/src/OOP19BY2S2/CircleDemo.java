
package OOP19BY2S2;

public class CircleDemo {
    public static void main(String [] args){
        Circle c1 = new Circle (); // we declare c1 as object varible of circle
        //Circle () is default construtor of Class Circle 
        c1.setRadius(1);
        System.out.println("Circle 1 = "+c1.radius);
        System.out.println("Circle 1 Area = " +c1.getarea());
        System.out.println("Circle 1 Perimertor =" +c1.getPerimeter());
        System.out.println("-----------------------------------------------------------");
        Circle c2;// c2 just be simple varable of Circle, it means c2 not yet to be object variable of Circle
        c2 = new Circle ();// c2 intantion to objust variable of Circle by keyword new and default condtructor
        c2.radius = 25; 
        System.out.println("Circle 2 = "+c2.radius);
        System.out.println("Circle 2 Area = " +c2.getarea());
        System.out.println("Circle 2 Perimertor =" +c2.getPerimeter());
        System.out.println("-----------------------------------------------------------");
        Circle c3 = new Circle();
        c3.setRadius (125); 
        System.out.println("Circle 3 = "+c3.radius);
        System.out.println("Circle 3 Area = " +c3.getarea());
        System.out.println("Circle 3 Perimertor =" +c3.getPerimeter());
                
        
    }
    
}
