package OOP19BY2S2;
import java.util.Scanner;
import java.text.*;


public class StudentDemo {
    public static void main(String [] args)throws ParseException{
       Scanner imput = new Scanner(System.in);
       SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
       Student stu1 = new  Student();// variable stud is object variable Student  
       System.out.print("Student ID :");
       stu1.setID(imput.nextInt());
       System.out.print("Student Frist Name: ");
       stu1.setFirstName(imput.next());
       System.out.print("Student Last Name: ");
       stu1.setLastName(imput.next());
       System.out.print("Student Gender :");
       stu1.setGender(imput.next());
       System.out.print("Student BirthDate :");
       // stu1.setBirthdate(new simpleDateFormat("dd-MM-yyyy").parse(imput.next()));
       stu1.setBirthdate(sdf.parse(imput.next()));
       System.out.println();
       System.out.println("Student ID:"+ stu1.getID());
       System.out.println("Student FullName: "+ stu1.getFullName());
       System.out.println("Student Gender: "+ stu1.getGender());
       //System.out.println("Birth Date ="+new SimpleDateFormat("dd-MM-yyyy").format(stu1.getBirthdate);
       System.out.println("Birthdate : "+sdf.format(stu1.getBirthdate()));
       
        
        
       
        
    }
   
    
    
    
}
