package OOP19BY2S2;


import java.util.*;

/**
 *
 * @author Asus
 */
public class Customer1 extends Person {
    private String cusid;
    private List<Account> acc;
    
    public Customer1(){
        this.cusid = "";
        this.acc = new ArrayList<>();
    }
    public Customer1(String cusid,int id, String ssn, String fname, String lname, String gender, Date birthdate, String address, String phone, Account acc){
        super(id,fname,lname,gender,birthdate,address,phone);
        this.cusid = cusid;
        this.acc = new ArrayList<>();
        this.acc.add(acc);
    }
    public void setCustomerID(String cusid){
        this.cusid = cusid;
    }
    public String getCustomerID(){return this.cusid;}
    
    public void setAccount(Account acc){
        this.acc.add(acc);
    }
    public void updateAccount(String accnum, Account nacc){
        for(Account ac : this.acc){
            if(ac.getAccountNumber().equals(accnum)){
                this.acc.set(this.acc.indexOf(ac), nacc);
            }
            // this.acc.replaceAll(ac->ac.getAccountNumber().equals
    }
    
}
    public void deleteAccount(String accnum){
        for(Account ac : this.acc){
            if(ac.getAccountNumber().equals(accnum))
                this.acc.remove(ac);
        }
    }

public Account getAccount(String accnum){
    for(Account ac: this.acc){
        if(ac.getAccountNumber().equals(accnum))
            return ac;
    }
    return null;
    }
public List<Account> getAccountList(){return this.acc;}
}
