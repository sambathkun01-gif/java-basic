/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import javax.swing.JOptionPane;






/**
 *
 * @author Asus
 */
public class AccountDemo {
    public static void main(String [] args) throws ParseException{
         Account acc = new Account (){};
         Date date = new SimpleDateFormat("dd-MM-YYYY").parse(LocalDate.now().format(DateTimeFormatter.ofPattern("dd-MM-YYYY")));
         String menu = "1.Create Account\n2. Deposit\n3. Withdraw\n4 show Balance"+"\n5. show Transaction\n6. Exit";
         do{
             int op = Integer.parseInt(JOptionPane.showInputDialog(menu));
             switch(op){
                 case 1: {String accnum = JOptionPane.showInputDialog("Input Account Number: ");
                    double amount = Double.parseDouble(JOptionPane.showInputDialog("Input Amount: "));
                    acc.setAccountNumber(accnum);
                    acc.deposit(date, amount);
                 }break;
                 case 2: acc.deposit(date,Double.parseDouble(JOptionPane.showInputDialog("Input account to deposit :")));break;
                 case 3: acc.withdraw(date,Double.parseDouble(JOptionPane.showInputDialog("Input account to withdraw :")));break;
                 case 4: String info = "Account Number :"+ acc.getAccountNumber()+
                         "\nBalance : "+ acc.getBalance()+
                         "$\nDeposit account :"+acc.getDepositAmount()+
                         "\nWithdraw :"+ acc.getWithdrawAmount()+
                         "$\nInterest Account :"+ acc.getInterestAmount() +" $";
                         JOptionPane.showMessageDialog(null, info);break;
                case 5: StringBuilder transactionInfo = new StringBuilder("Transaction History:\n");
                        SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
                        for (  AccountHistory show : acc.getTransactionList()) {
                        transactionInfo.append("Date: ").append(dateFormat.format(show.getTransactionDate()))
                                       .append(", Type: ").append(show.getTransactionName())
                                       .append(", Amount: ").append(show.getTransactionAccount()).append("$\n");
                        }
                        JOptionPane.showMessageDialog(null, transactionInfo.toString());break;
                       
                 case 6: return;                 
             }
         }while(true);
    }   
}
