/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

/**
 *
 * @author Asus
 */
public class Student1 {
    protected final static int NUM_OF_TESTS = 3;
    protected String name;
    protected int[] test;
    protected String courseGrade;
    public Student1(){
         this.name = "No Name";
         test = new int[NUM_OF_TESTS];
    }
	public Student1(String studentName){//ចង់បើក ក៏បាន​ អត់ ក៏បាន
		name = studentName;
		test = new int[NUM_OF_TESTS];
	}
        public String getCourseGrade(){
		return courseGrade;
	}
	public String getName(){
		return name;
	}
	public int getTestScore(int testNumber ){
		return test[testNumber-1];
	}
	public void setName(String newName){
		name = newName;
	}
	public void setTestScore(int testNumber, int testScore){
		test[testNumber-1] = testScore;
	}
}



    

