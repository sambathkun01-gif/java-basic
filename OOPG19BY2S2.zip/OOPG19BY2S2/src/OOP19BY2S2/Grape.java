package OOP19BY2S2;

public class Grape extends Fruit {
    
    private String taste;
    private String vitamin;
    
//    public Grape(){
//        super();
//    }
    public Grape(String taste, String vitamin){
        this.taste = taste;
        this.vitamin = vitamin;
    }
    public String getTaste(){
        return "sweet";
    }
         
    public String getVitamin(){
        return "Vitamin C";
    }
    @Override
    public String getColor(){
        return "red";
    }
    
    
    
}


   
    
  
