/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;


import java.util.Date;

/**
 *
 * @author Asus
 */
public final class AccountHistory {
    private Date transdate;
    private double deposit;
    private double withdrawal;
    private double interest;
    private String transname;
    
    public AccountHistory(Date transdate, String transname,double amount){
       
        
        if (transname.equalsIgnoreCase("deposit")) this.deposit = amount;
        else if (transname.equalsIgnoreCase("withdraw")) this.withdrawal = amount;
        else this.interest = amount;
        this.transdate = transdate;
        this.transname = transname;
        
        
    }
    public Date getTransactionDate(){return this.transdate;}
    public String getTransactionName(){return this.transname;}
    public double getTransactionAccount(){
        return this.transname.equalsIgnoreCase("deposit")? this.deposit:
                this.transname.equalsIgnoreCase("withdraw")? this.withdrawal:
                this.interest;
        
    }
         
}
