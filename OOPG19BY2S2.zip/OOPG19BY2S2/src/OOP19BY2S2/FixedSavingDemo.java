package OOP19BY2S2;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Date;

public class FixedSavingDemo {
    public static void main(String [] args){
        Date current = Date.from(LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant());
        FixedSaving fs = new FixedSaving(current,"",11,"",0.33,1000);
        
        fs.deposit(current, 1000);
        String str = "Start Date: "+ new SimpleDateFormat("dd/MM/yyyy").format(fs.getStateDate())+
                "\nEnd Date: "+new SimpleDateFormat("dd/MM/yyyy").format(fs.getEndDate())+
                "\nAccount Number: " + fs.getAccountNumber() + "\nPeriod: "+ fs.getMonthPeriod() + "\nDestination Number: "+ 
                fs.getDepositAmount()+"\nYerly Interest Rate: "+ fs.getYearlyInterestRate()+"\nAmount: "+ fs.getBalance();
        System.out.print(str);
    }
    
}
