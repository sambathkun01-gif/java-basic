/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

/**
 *
 * @author Asus
 */
public class SentenceCount {
    private String st;
    public SentenceCount(){}
    public SentenceCount(String st){
        this.st=st;
    }
    public void setSentenceCount(String st){
        this.st=st;
    }
    public String toString (){
        return this.st;
    }
    public int wordCount(){return this.st.split(" ").length;}
    public int SentenCount(){
        int scount = 0;
        boolean issentence = true;
        for (int i=0; i <this.st.length(); i++){
            switch(this.st.charAt(i)){
                case '.' : {
                   if(this.st.charAt(i-2)== 'M' && this.st.charAt(i-1)== 'r')
                    issentence = false;
                   else if(this.st.charAt(i-2)== 'D' && this.st.charAt(i-1)== 'r')
                    issentence = false;
                   else if(this.st.charAt(i-2)== 'M' && this.st.charAt(i-1)== 's')
                    issentence = false;
                   if (issentence) scount++;
                   
                }break;
        
                case '?': scount++;
                case '!': scount++;
        }
            issentence = true;
      }
        return scount;
    
    }
}