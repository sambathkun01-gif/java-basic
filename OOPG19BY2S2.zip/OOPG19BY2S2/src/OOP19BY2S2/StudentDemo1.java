/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

/**
 *
 * @author Asus
 */
public class StudentDemo1 {
    public static void main(String [] args){
      UndergraduteStudent st1 = new UndergraduteStudent();
      st1.setName("Sambath");
      st1.setTestScore(1, 50);
      st1.setTestScore(2, 80);
      st1.setTestScore(3, 80);
      st1.computeCourseGrade();
      System.out.println("Result of " + st1.getName()+"\nis "+st1.getCourseGrade());
      System.out.println("=============================================");
      GraduateStudent st2 = new GraduateStudent();
      st2.setName("soriya");
      st2.setTestScore(1, 30);
      st2.setTestScore(2, 20);
      st2.setTestScore(3, 10);
      st2.computeCourseGrade();
      System.out.println("Result of " + st2.getName()+"\nis "+st2.getCourseGrade());
      
      
    } 
}
