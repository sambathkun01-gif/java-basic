package OOP19BY2S2;

public class Fruit {
 
    private boolean isEatable;
    private String color;
    public Fruit() {
        this.isEatable = true;
        this.color = "";
    }
    public Fruit(String color){
        this.color = color;
        this.isEatable = true;
    }
    public String getColor (){return this.color;}
    public boolean getIsEatable(){return this.isEatable;}
    
    
}


