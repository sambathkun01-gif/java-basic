/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package OOP19BY2S2;

import java.util.Date;

/**
 *
 * @author Asus
 */
public class CurrentSaving extends Account {
    private Date startdate;
    private double yir;
    private boolean isactive;
    public CurrentSaving(){
     super();
     this.isactive = true;
     }
    public  CurrentSaving (Date stardate,String accnum,double yir,double amount){
        super(stardate,accnum,amount);
         this.startdate = stardate; 
         this.yir = yir;
         this.isactive = true;
         
    }
    public void setStartDate (Date startdate){
        this.startdate = startdate;
    }
    public void setYir (double yir){
        this.yir = yir/100;
    }
    public void setIsactive(boolean active){
        
        isactive = active;
    }
    public Date getStartDate(){
        return startdate;
    }
    public double getYir (){
        return yir;
    }
    public boolean getIsActive(){
         return isactive;
    }
        
}
