package OOP19BY2S2;

import java.text.*;
import java.util.Scanner;

//    
/**
 *
 * @author Asus
 */
public class PersonDemo {

    public static void main(String[] args) throws ParseException {
        Scanner input = new Scanner(System.in);
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MM-yyyy");
        Person p1 = new Person();//p1 is object variable of class Person
        System.out.print("Input Person ID :");
        p1.setID(Integer.parseInt(input.nextLine()));
        System.out.print("Input Frist Name:");
        p1.setFirstName(input.nextLine());
        System.out.print("Input Last Name :");
        p1.setLastName(input.nextLine());
        System.out.print("Input gender :");
        p1.setGender(input.nextLine());
        System.out.print("Input BirthDate :");
        p1.setBirthdate(sdf.parse(input.nextLine()));
        System.out.print("Input Address :");
        p1.setaddress(input.nextLine());
        System.out.print("Input CellPhone :");
        p1.setPhone(input.nextLine());
        p1.showinfo();

    }
}
