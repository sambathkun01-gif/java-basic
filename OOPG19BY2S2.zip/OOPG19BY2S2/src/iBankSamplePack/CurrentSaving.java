
package iBankSamplePack;


public class CurrentSaving extends Account implements Interestable {
    private static final double INTEREST_RATE = 0.02; // 2% annual interest

    public CurrentSaving(double initialBalance) {
        super(initialBalance);
    }

    @Override
    public void addInterest() {
        double interest = balance * INTEREST_RATE / 12; // Monthly interest
        balance += interest;
        System.out.println("Interest added: " + interest);
    }
}



