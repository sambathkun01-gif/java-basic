/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package iBankSamplePack;

/**
 *
 * @author Asus
 */
public class FixedSaving extends Account implements Interestable {
    private static final double INTEREST_RATE = 0.05; // 5% annual interest
    private int termMonths;

    public FixedSaving(double initialBalance, int termMonths) {
        super(initialBalance);
        this.termMonths = termMonths;
    }

    @Override
    public void addInterest() {
        double interest = balance * INTEREST_RATE * termMonths / 12;
        balance += interest;
        System.out.println("Interest added for " + termMonths + " months: " + interest);
    }

    @Override
    public void withdraw(double amount) {
        System.out.println("Cannot withdraw from Fixed Saving account before term ends.");
    }
}