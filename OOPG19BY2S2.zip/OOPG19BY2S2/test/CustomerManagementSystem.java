/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Asus
 */
//*import javax.swing.*;

//*import javax.swing.*;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.regex.PatternSyntaxException;

public class CustomerManagementSystem extends JFrame {
    private JRadioButton customerRadioButton;
    private JRadioButton customerNameRadioButton;
    private JTable customerTable;
    private DefaultTableModel tableModel;
    private ButtonGroup radioButtonGroup;
    private JTextField searchField;
    private TableRowSorter<DefaultTableModel> rowSorter;

    public CustomerManagementSystem() {
        initializeUI();
        setupComponents();
        loadSampleData();
    }

    private void initializeUI() {
        setTitle("Customer Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 600);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
    }

    private void setupComponents() {
        // Create top panel with radio buttons and search
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Create radio buttons panel
        JPanel radioPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        radioPanel.setBorder(BorderFactory.createTitledBorder("View Options"));
        
        customerRadioButton = new JRadioButton("Customer ", true);
        customerNameRadioButton = new JRadioButton("Customer Names ");
        
        radioButtonGroup = new ButtonGroup();
        radioButtonGroup.add(customerRadioButton);
        radioButtonGroup.add(customerNameRadioButton);
        
        radioPanel.add(customerRadioButton);
        radioPanel.add(customerNameRadioButton);
        
        topPanel.add(radioPanel, BorderLayout.NORTH);

        // Create search panel
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.LEFT));
        searchPanel.setBorder(BorderFactory.createTitledBorder("Search"));
        
        searchField = new JTextField(15);
        JButton searchButton = new JButton("Search ID");
        JButton clearButton = new JButton("Clear");
        
        searchPanel.add(new JLabel("Search by ID:"));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        searchPanel.add(clearButton);
        
        topPanel.add(searchPanel, BorderLayout.SOUTH);

        add(topPanel, BorderLayout.NORTH);

        // Create table with initial columns for customer details
        String[] customerColumns = {"ID", "Account Customer", "Status", "Type"};
        tableModel = new DefaultTableModel(customerColumns, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table non-editable
            }
            
            @Override
            public Class<?> getColumnClass(int columnIndex) {
                return String.class; // All columns contain strings
            }
        };
        
        customerTable = new JTable(tableModel);
        customerTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        // Initialize row sorter for search functionality
        rowSorter = new TableRowSorter<>(tableModel);
        customerTable.setRowSorter(rowSorter);
        
        JScrollPane tableScrollPane = new JScrollPane(customerTable);
        tableScrollPane.setBorder(BorderFactory.createTitledBorder("Customer Data"));
        
        add(tableScrollPane, BorderLayout.CENTER);

        // Add action listeners
        customerRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCustomerDetails();
            }
        });

        customerNameRadioButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                showCustomerNamesOnly();
            }
        });


searchButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchById();
            }
        });

        clearButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearSearch();
            }
        });

        // Add Enter key listener to search field
        searchField.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                searchById();
            }
        });
    }

    private void showCustomerDetails() {
        // Switch to customer details view
        String[] columns = {"ID", "Account Customer", "Status", "Type"};
        tableModel.setColumnIdentifiers(columns);
        refreshTableData();
        setupRowSorter();
    }

    private void showCustomerNamesOnly() {
        // Switch to customer names only view
        String[] columns = {"Account Customer"};
        tableModel.setColumnIdentifiers(columns);
        refreshTableData();
        setupRowSorter();
    }

    private void setupRowSorter() {
        // Reinitialize row sorter after column changes
        rowSorter = new TableRowSorter<>(tableModel);
        customerTable.setRowSorter(rowSorter);
    }

    private void searchById() {
        String searchText = searchField.getText().trim();
        
        if (searchText.isEmpty()) {
            clearSearch();
            return;
        }

        try {
            // Only search if we're in customer details view (where ID column exists)
            if (customerRadioButton.isSelected()) {
                // Search in the first column (ID)
                RowFilter<DefaultTableModel, Object> rf = RowFilter.regexFilter("(?i)" + searchText, 0);
                rowSorter.setRowFilter(rf);
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Search by ID is only available in 'Customer Details' view", 
                    "Search Not Available", 
                    JOptionPane.WARNING_MESSAGE);
            }
        } catch (PatternSyntaxException ex) {
            JOptionPane.showMessageDialog(this, 
                "Invalid search pattern", 
                "Search Error", 
                JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearSearch() {
        searchField.setText("");
        rowSorter.setRowFilter(null);
    }

    private void refreshTableData() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Add data based on current view
        if (customerRadioButton.isSelected()) {
            // Add customer details data
            Object[] row1 = {"C001", "John Doe", "Active", "Premium"};
            Object[] row2 = {"C002", "Jane Smith", "Inactive", "Standard"};
            Object[] row3 = {"C003", "Bob Johnson", "Active", "Standard"};
            Object[] row4 = {"C004", "Alice Brown", "Pending", "Premium"};
            Object[] row5 = {"C005", "Charlie Wilson", "Active", "Basic"};
            Object[] row6 = {"C006", "Emma Davis", "Active", "Premium"};
            Object[] row7 = {"C007", "Michael Lee", "Suspended", "Standard"};
            Object[] row8 = {"C008", "Sarah Miller", "Active", "Basic"};
            
            tableModel.addRow(row1);
            tableModel.addRow(row2);
            tableModel.addRow(row3);
            tableModel.addRow(row4);
            tableModel.addRow(row5);
            tableModel.addRow(row6);
            tableModel.addRow(row7);
            tableModel.addRow(row8);
        } else {
            // Add customer names only
            Object[] row1 = {"John Doe"};
            Object[] row2 = {"Jane Smith"};


Object[] row3 = {"Bob Johnson"};
            Object[] row4 = {"Alice Brown"};
            Object[] row5 = {"Charlie Wilson"};
            Object[] row6 = {"Emma Davis"};
            Object[] row7 = {"Michael Lee"};
            Object[] row8 = {"Sarah Miller"};
            
            tableModel.addRow(row1);
            tableModel.addRow(row2);
            tableModel.addRow(row3);
            tableModel.addRow(row4);
            tableModel.addRow(row5);
            tableModel.addRow(row6);
            tableModel.addRow(row7);
            tableModel.addRow(row8);
        }
    }

    private void loadSampleData() {
        // Load initial data
        refreshTableData();
        setupRowSorter();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                try {
                    UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
                
                CustomerManagementSystem frame = new CustomerManagementSystem();
                frame.setVisible(true);
            }
        });
    }
}